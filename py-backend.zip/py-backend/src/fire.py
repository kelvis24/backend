from flask import Flask, request
import firebase_admin
from firebase_admin import credentials, firestore
from flask_cors import CORS
import json
from datetime import datetime
import numpy as np

class Firebase:
    def __init__(self, cred):
        self.app = Flask(__name__)
        CORS(self.app)
        self.default_app = cred

    def read_from_DB(self, collection_id, document_id):
        try:
            db = firestore.client()
            doc_ref = db.collection(collection_id).document(document_id)
            doc = doc_ref.get()
            if doc.exists:
                return doc.to_dict()
            else:
                print(f"No such document '{document_id}' in collection '{collection_id}'")
                return None

        except Exception as e:
            print(f"Error: {str(e)}")
            return None

    def get_collection(self, collection_id):
        try:
            db = firestore.client()
            docs = db.collection(collection_id).get()
            return [doc.to_dict() for doc in docs]

        except Exception as e:
            print(f"Error: {str(e)}")
            return None


    def query_by_property(self, collection_id, property_name, property_value):
        try:
            # Get a Firestore client
            db = firestore.client()
            # Query Firestore based on property
            docs = db.collection(collection_id).where(property_name, "==", property_value).get()
            # Return list of documents matching the query
            return [doc.to_dict() for doc in docs]
        except Exception as e:
            print(f"Error: {str(e)}")
            return None


    def query_vectors_by_user(self, collection_id, username):
        try:
            # Get a Firestore client
            db = firestore.client()
            # Query Firestore based on user property
            docs = db.collection(collection_id).where("username", "==", username).get()
            # Extract vectors and texts from documents
            vectors_texts = [
                {
                    "vector": doc.to_dict().get('vector', None),
                    "text": doc.to_dict().get('text', '')
                }
                for doc in docs
            ]

            # Filter out documents where vector is missing or empty, or text is missing
            vectors_texts = [vt for vt in vectors_texts if vt["vector"] and vt["text"]]
            print("vectors_texts:", vectors_texts)

            # Find the maximum vector length
            max_vector_length = max(len(vt["vector"]) for vt in vectors_texts)
            print("max_vector_length:", max_vector_length)

            # Pad vectors to have the same length
            for vt in vectors_texts:
                # First, ensure that vt["vector"] is indeed a list
                if isinstance(vt["vector"], list):
                    vector_length = len(vt["vector"])
                    if vector_length < max_vector_length:
                        # Calculate the number of zeros needed for padding
                        padding_length = max_vector_length - vector_length
                        # Extend the vector with zeros to match the max_vector_length
                        vt["vector"].extend([0] * padding_length)
                else:
                    # This is a catch-all for debugging, in case vt["vector"] isn't a list as expected
                    print(f"Unexpected type for 'vector': {type(vt['vector'])}. Expected list.")
            return vectors_texts
        except Exception as e:
            print(f"Error: {str(e)}")
            return None


    def create_user_data_file(self, collection_id, property_name, property_value):
        try:
            # Generate timestamp
            timestamp = datetime.now()
            # Construct filename
            filename = f"{property_value}_{timestamp.strftime('%Y%m%d_%H%M%S')}.txt"
            # Get user data based on property
            user_data_list = self.query_by_property(collection_id, property_name, property_value)
            if user_data_list:
                # Extract 'text' field from each document
                texts = [user_data.get('text', '') for user_data in user_data_list]
                # Write consolidated user data to file
                with open(filename, "w") as file:
                    file.write('\n'.join(texts))
                return filename
            else:
                print("No user data found for the given property.")
                return None

        except Exception as e:
            print(f"Error: {str(e)}")
            return None


if __name__ == "__main__":
    cred = credentials.Certificate("/content/realestatemgmt-d3faa-firebase-adminsdk-hhsti-34f510350a (1).json") #correct this directory to one in your local
    default_app = firebase_admin.initialize_app(cred) # run this line only once!!
    firebase = Firebase(default_app)

    # Test read_from_DB
    document_data = firebase.read_from_DB("Organizations", "393d04b9-6fb2-4556-bfc5-25831991e3d2")
    if document_data:
        print("\n\n Document data from specified Organization ID:\n\n", document_data)
    else:
        print("Document not found or error occurred.")

    # Test get_collection
    collection_data = firebase.get_collection("users")
    if collection_data:
        print("\n\n Get all users in database:")
        for document in collection_data:
            print(document)
    else:
        print("Collection empty or error occurred.")

    #Get all user data by username
    query_data = firebase.query_by_property(collection_id="users", property_name="email", property_value="ekimara@iastate.edu")
    if query_data:
        print("\n\n Query data for by giving specific propperty type like email and email value:\n\n", query_data)
    else:
        print("No documents found matching the query or error occurred.")

    #Get all user data by username
    query_data = firebase.query_by_property(collection_id="users", property_name="firstName", property_value="Lwembo")
    if query_data:
        print("\n\n Query data for by giving specific propperty type like firstName and firstName value:\n\n", query_data)
    else:
        print("No documents found matching the query or error occurred.")
