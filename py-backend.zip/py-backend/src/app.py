from flask import Flask, jsonify, render_template, request, make_response, session
import collections
from collections import abc
from weasyprint import HTML

collections.Iterable = abc.Iterable
collections.MutableMapping = abc.MutableMapping
collections.Mapping = abc.Mapping
from apscheduler.schedulers.background import BackgroundScheduler

import firebase_admin
from firebase_admin import credentials, initialize_app, storage
from datetime import datetime
from flask_cors import CORS
import uuid
import json
import requests
from datetime import datetime
from decimal import *
# from crontab import CronT

import pandas as pd
from io import StringIO

# boto 3 setup docs: https://boto3.amazonaws.com/v1/documentation/api/latest/guide/quickstart.html
import boto3
from boto3.dynamodb.conditions import Key, Attr

from app.src.services.getPropertyList import get_property_list
from app.src.services.getPropertyDetails import get_property_details
from app.src.services.getBuildingList import get_building_list
from app.src.services.getUnitList import get_unit_list
from app.src.services.getServiceRequestList import get_service_request_list
from app.src.services.getMonthlyReportDetails import get_monthly_report_details
from app.src.services.addMonthlyReport import add_monthly_report
from app.src.services.getYearlyReportDetails import get_yearly_report_details
from app.src.services.addYearlyReportDetails import add_yearly_report
from app.src.services.deleteMonthlyReport import delete_monthly_report
from app.src.services.deleteYearlyReport import delete_yearly_report
from app.src.services.addYearOnRecord import add_year_on_record
from app.src.services.deleteYearOnRecord import delete_year_on_record
from app.src.services.updateYearOnRecord import update_year_on_record
from app.src.services.getYearOnRecord import get_year_on_record
from app.src.services.getMonthlyReportList import get_monthly_report_list
from app.src.services.getYearlyReportList import get_yearly_report_list
from app.src.fire import Firebase

# Get the service resource.
dynamodb = boto3.resource("dynamodb", "us-east-2")

# Instantiate a table resource object without actually
# creating a DynamoDB table. Note that the attributes of this table
# are lazy-loaded: a request is not made nor are the attribute
# values populated until the attributes
# on the table resource are accessed or its load() method is called.
table = dynamodb.Table("Property")

# Print out some data about the table.
# This will cause a request to be made to DynamoDB and its attribute
# values will be set based on the response.
# print(table)

app = Flask(__name__)
app.secret_key = 'your_secret_key' 
CORS(app)

project_id = "realestatemgmt-d3faa"
# Initialize Firebase Admin SDK with your credentials
cred = credentials.Certificate(
    "app/src/realestatemgmt-d3faa-firebase-adminsdk-hhsti-34f510350a.json"
)
# cred = credentials.Certificate(
#     "/Users/johannguepjop/work/property-mgmt/py-backend/src/realestatemgmt-d3faa-firebase-adminsdk-hhsti-34f510350a.json"
# )
firebase = Firebase(cred)

# firebase_admin.initialize_app(cred, {"storageBucket": f"{project_id}.appspot.com"})

def getLastDayOfMonth(month, year):
    if month == 2:
        if year % 4 == 0:
            return 29
        return 28
    elif month in [4, 6, 9, 11]:
        return 30
    return 31


def runDailyWorkflow():
    # Get the service resource.
    dynamodb = boto3.resource("dynamodb", "us-east-2")

    # Instantiate a table resource object without actually
    # creating a DynamoDB table. Note that the attributes of this table
    # are lazy-loaded: a request is not made nor are the attribute
    # values populated until the attributes
    # on the table resource are accessed or its load() method is called.
    table = dynamodb.Table("Property")
    date = datetime.now()

    userList = firebase.get_collection("users")
    if date.day == 1:
        if date.month == 1:
            for i in range(0, len(userList)):
                updateYearlyFinanceReport(
                    date.year - 1,
                    12,
                    31,
                    "user",
                    userList[i].get("uid", ""),
                    True,
                )
        else:
            lastDay = getLastDayOfMonth(date.month - 1, date.year)
            for j in range(0, len(userList)):
                propertyList = get_property_list(
                    userList[i].get("uid", ""),
                )
                updateMonthlyUserFianceReport(
                    date.year,
                    date.month - 1,
                    lastDay,
                    propertyList,
                    userList[i].get("uid", ""),
                    True,
                )

            for i in range(0, len(userList)):
                updateYearlyFinanceReport(
                    date.year,
                    date.month - 1,
                    lastDay,
                    "user",
                    userList[i].get("uid", ""),
                    False,
                )
    for i in range(0, len(userList)):
        updateYearlyFinanceReport(
            date.year,
            date.month,
            date.day,
            "user",
            userList[i].get("uid", ""),
            False,
        )
    print("updated yearly reports")

sched = BackgroundScheduler(daemon=True)
sched.add_job(runDailyWorkflow, "interval", days=1)
sched.start()

# print(job.enable(False))


@app.route("/")
def home():
    # Create a simple HTML page with an explanation of what Safety Scan does
    return render_template("/index.html")


@app.route("/organization")
def organization():
    # Create a simple HTML page with an explanation of what Safety Scan does
    return render_template("/organization.html")


@app.route("/api/v1/report-list")
def reportList():
    # Create a simple HTML page with an explanation of what Safety Scan does
    # return get_yearly_report_list("2023", "user")
    return firebase.get_collection("users")


@app.route(
    "/api/v1/finance/report/<currentYear>/<currentMonth>/<currentDay>/<entityType>/<entityID>/<close>"
)
def updateYearlyFinanceReport(
    currentYear, currentMonth, currentDay, entityType, entityID, close
):
    shouldUpdate = False
    yearlyReport = get_yearly_report_details(entityType, entityID, currentYear)
    yearlyReportId = f"{currentYear}-{entityType}-{entityID}"
    if "status" in yearlyReport:
        shouldUpdate = True
        if yearlyReport["status"] == "Closed":
            return yearlyReport
    totalRent = Decimal(yearlyReport["confirmedRentRevenue"])
    totalFees = Decimal(yearlyReport["confirmedFeesRevenue"])
    totalOther = Decimal(yearlyReport["confirmedOtherRevenue"])
    totalLostRent = Decimal(yearlyReport["confirmedLostRentExpenses"])
    totalRenovation = Decimal(yearlyReport["confirmedRenovationExpenses"])
    totalRepairs = Decimal(yearlyReport["confirmedrepairsExpenses"])
    totalOtherExpenses = Decimal(yearlyReport["confirmedOtherExpenses"])

    propertyList = get_property_list(entityID) if entityType == "user" else []
    for i in range(0, len(propertyList)):
        property = propertyList[i]
        updateYearlyFinanceReport(
            currentYear, currentMonth, currentDay, "property", property["id"], close
        )
    monthlyReport = (
        updateMonthlyUserFianceReport(
            currentYear, currentMonth, propertyList, entityID, close
        )
        if entityType == "user"
        else updateMonthlyEntityFinanceReport(
            currentYear, currentMonth, entityType, entityID, close
        )
    )
    numOccupied = monthlyReport.get("numOccupied", 0)
    numVacant = monthlyReport.get("numVacant", 0)
    numRenovation = monthlyReport.get("numRenovation", 0)
    totalRent = Decimal(yearlyReport["confirmedRentRevenue"]) + monthlyReport.get(
        "rentRevenue", Decimal(0)
    )
    totalFees = Decimal(yearlyReport["confirmedFeesRevenue"]) + monthlyReport.get(
        "feesRevenue", Decimal(0)
    )
    totalOther = Decimal(yearlyReport["confirmedOtherRevenue"]) + monthlyReport.get(
        "otherRevenue", Decimal(0)
    )
    totalLostRent = Decimal(
        yearlyReport["confirmedLostRentExpenses"]
    ) + monthlyReport.get("lostRentExpenses", Decimal(0))
    totalRenovation = Decimal(
        yearlyReport["confirmedRenovationExpenses"]
    ) + monthlyReport.get("renovationExpenses", Decimal(0))
    totalRepairs = Decimal(
        yearlyReport["confirmedrepairsExpenses"]
    ) + monthlyReport.get("repairsExpenses", Decimal(0))
    totalOtherExpenses = Decimal(
        yearlyReport["confirmedOtherExpenses"]
    ) + monthlyReport.get("otherExpenses", Decimal(0))
    totalRevenue = totalFees + totalRent + totalOther
    totalExpense = totalRepairs + totalLostRent + totalRenovation + totalOtherExpenses
    totalNet = totalRevenue - totalExpense
    date = datetime.now()
    reportPayload = {
        "id": yearlyReportId,
        "entityType": entityType,
        "entityID": entityID,
        "rentRevenue": totalRent,
        "feesRevenue": totalFees,
        "otherRevenue": totalOther,
        "totalRevenue": totalRevenue,
        "lostRentExpenses": totalLostRent,
        "repairsExpenses": totalRepairs,
        "renovationExpenses": totalRenovation,
        "otherExpenses": totalOtherExpenses,
        "totalExpenses": totalExpense,
        "status": "Closed" if close == "Closed" else "InProgress",
        "net": totalNet,
        "numOccupied": numOccupied,
        "numVacant": numVacant,
        "numRenovation": numRenovation,
        "year": currentYear,
        "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
        "createdAt": (
            datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z")
            if not shouldUpdate
            else monthlyReport["createdAt"]
        ),
        "confirmedRentRevenue": (
            totalRent if close == "Closed" else yearlyReport["confirmedRentRevenue"]
        ),
        "confirmedFeesRevenue": (
            totalFees if close == "Closed" else yearlyReport["confirmedFeesRevenue"]
        ),
        "confirmedOtherRevenue": (
            totalOther if close == "Closed" else yearlyReport["confirmedOtherRevenue"]
        ),
        "confirmedTotalRevenue": (
            totalRevenue if close == "Closed" else yearlyReport["confirmedTotalRevenue"]
        ),
        "confirmedLostRentExpenses": (
            totalLostRent
            if close == "Closed"
            else yearlyReport["confirmedLostRentExpenses"]
        ),
        "confirmedRenovationExpenses": (
            totalRenovation
            if close == "Closed"
            else yearlyReport["confirmedRenovationExpenses"]
        ),
        "confirmedrepairsExpenses": (
            totalRepairs
            if close == "Closed"
            else yearlyReport["confirmedrepairsExpenses"]
        ),
        "confirmedOtherExpenses": (
            totalOtherExpenses
            if close == "Closed"
            else yearlyReport["confirmedOtherExpenses"]
        ),
        "confirmedtotalExpenses": (
            totalExpense
            if close == "Closed"
            else yearlyReport["confirmedtotalExpenses"]
        ),
    }
    if shouldUpdate:
        deleteYearlyReport = delete_yearly_report(yearlyReportId)
        updatedYearlyReport = add_yearly_report(reportPayload)
    else:
        newYearlyReport = add_yearly_report(reportPayload)
        if entityType == "user":
            yearRecords = get_year_on_record(f"{entityID}-year-records")
            if "years" in yearRecords:
                newYears = yearRecords["years"]
                newYears.append(f"{currentYear}")
                update_year_on_record(
                    yearRecords["id"],
                    newYears,
                    datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
                )
            else:
                payload = {
                    "id": f"{entityID}-year-records",
                    "userID": entityID,
                    "years": [f"{currentYear}"],
                    "createdAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
                    "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
                }
                add_year_on_record(payload)
    return reportPayload


def updateMonthlyUserFianceReport(
    currentYear, currentMonth, propertyList, userID, close
):
    userMonthlyReport = get_monthly_report_details(
        entityType="user", entityID=userID, month=currentMonth, year=currentYear
    )
    shouldUpdate = False
    if "status" in userMonthlyReport:
        shouldUpdate = True
        if userMonthlyReport["status"] == "Closed":
            return userMonthlyReport
    totalRent = Decimal(0)
    totalFees = Decimal(0)
    totalOther = Decimal(0)
    totalLostRent = Decimal(0)
    totalRenovation = Decimal(0)
    totalRepairs = Decimal(0)
    totalOtherExpenses = Decimal(0)
    numOccupied = 0
    numVacant = 0
    numRenovation = 0
    for i in range(0, len(propertyList)):
        property = propertyList[i]
        monthlyReport = updateMonthlyEntityFinanceReport(
            currentYear,
            currentMonth,
            "property",
            property.get("id", ""),
            close,
        )
        numOccupied += monthlyReport.get("numOccupied", 0)
        numVacant += monthlyReport.get("numVacant", 0)
        numRenovation += monthlyReport.get("numRenovation", 0)
        totalRent += monthlyReport.get("rentRevenue", Decimal(0))
        totalFees += monthlyReport.get("feesRevenue", Decimal(0))
        totalOther += monthlyReport.get("otherRevenue", Decimal(0))
        totalLostRent += monthlyReport.get("lostRentExpenses", Decimal(0))
        totalRenovation += monthlyReport.get("renovationExpenses", Decimal(0))
        totalRepairs += monthlyReport.get("repairsExpenses", Decimal(0))
        totalOtherExpenses += monthlyReport.get("otherExpenses", Decimal(0))
    totalRevenue = totalFees + totalRent + totalOther
    totalExpense = totalRepairs + totalLostRent + totalRenovation + totalOtherExpenses
    totalNet = totalRevenue - totalExpense
    date = datetime.now()
    reportPayload = {
        "id": f"{currentYear}-{currentMonth}-user-{userID}",
        "yearlyReportId": f"{currentYear}-user-{userID}",
        "status": "Closed" if close == "Closed" else "InProgress",
        "entityType": "user",
        "entityID": userID,
        "rentRevenue": Decimal(totalRent),
        "feesRevenue": Decimal(totalFees),
        "otherRevenue": Decimal(totalOther),
        "totalRevenue": Decimal(totalRevenue),
        "lostRentExpenses": Decimal(totalLostRent),
        "repairsExpenses": Decimal(totalRepairs),
        "renovationExpenses": Decimal(totalRenovation),
        "otherExpenses": Decimal(totalOtherExpenses),
        "totalExpenses": Decimal(totalExpense),
        "net": Decimal(totalNet),
        "numOccupied": numOccupied,
        "numVacant": numVacant,
        "numRenovation": numRenovation,
        "month": currentMonth,
        "year": currentYear,
        "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
        "createdAt": (
            datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z")
            if not shouldUpdate
            else userMonthlyReport.get("createdAt", "")
        ),
    }
    if shouldUpdate:
        deleteMonthlyReport = delete_monthly_report(userMonthlyReport["id"])
        updatedMonthlyReport = add_monthly_report(reportPayload)
    else:
        newMonthlyReport = add_monthly_report(reportPayload)
    return reportPayload


def updateMonthlyEntityFinanceReport(
    currentYear, currentMonth, entityType, entityID, close
):
    monthlyReport = get_monthly_report_details(
        entityType=entityType, entityID=entityID, month=currentMonth, year=currentYear
    )
    shouldUpdate = False
    if "status" in monthlyReport:
        shouldUpdate = True
        if monthlyReport["status"] == "Closed":
            return monthlyReport
    totalRent = monthlyReport.get("rentRevenue", Decimal(0))
    totalFees = Decimal(0)
    totalOther = Decimal(0)
    totalOtherExpenses = Decimal(0)
    totalLostRent = Decimal(0)
    totalRenovation = Decimal(0)
    totalRepairs = Decimal(0)
    numOccupied = 0
    numVacant = 0
    numRenovation = 0
    if entityType == "property":
        # on the first of the month, create the report
        propertyExpenses = getTotalExpenses(
            "property", entityID, currentMonth, currentYear
        )
        totalFees += propertyExpenses["totalFees"]
        totalOther += propertyExpenses["totalOther"]
        totalRepairs += propertyExpenses["totalRepairs"]
        totalLostRent += propertyExpenses["totalLostRent"]
        totalRenovation += propertyExpenses["totalRenovation"]
        totalOtherExpenses += propertyExpenses["totalOtherExpenses"]
        buildingList = get_building_list("", propertyID=entityID)
        for i in range(0, len(buildingList)):
            building = buildingList[i]
            if building.get("type", "Single") == "Multiple":
                if building.get("status", "None") == "Occupied":
                    numOccupied += 1
                    # rent is only added when the report is first created only
                    # this should be happening every first of the month
                    if shouldUpdate == False:
                        totalRent += building.get("rent", Decimal(0))

                elif building.get("status", "None") == "Vacant":
                    numVacant += 1
                elif building.get("status", "None") == "Renovation":
                    numRenovation += 1

                buildingExpenses = getTotalExpenses(
                    "building", building["id"], currentMonth, currentYear
                )
                totalFees += buildingExpenses["totalFees"]
                totalOther += buildingExpenses["totalOther"]
                totalOtherExpenses += buildingExpenses["totalOtherExpenses"]
                totalRepairs += buildingExpenses["totalRepairs"]
                totalLostRent += buildingExpenses["totalLostRent"]
                totalRenovation += buildingExpenses["totalRenovation"]
            else:
                unitList = get_unit_list("", buildingID=building["id"])
                for j in range(0, len(unitList)):
                    unit = unitList[j]
                    if unit.get("status", "") == "Occupied":
                        numOccupied += 1
                        # rent is only added when the report is first created only
                        # this should be happening every first of the month
                        if shouldUpdate == False:
                            totalRent += unit.get("rent", Decimal(0))

                    elif unit.get("status", "None") == "Vacant":
                        numVacant += 1
                    elif unit.get("status", "None") == "Vacant":
                        numRenovation += 1
                    unitExpenses = getTotalExpenses(
                        "unit", unit["id"], currentMonth, currentYear
                    )
                    totalFees += unitExpenses["totalFees"]
                    totalOther += unitExpenses["totalOther"]
                    totalOtherExpenses += unitExpenses["totalOtherExpenses"]
                    totalRepairs += unitExpenses["totalRepairs"]
                    totalLostRent += unitExpenses["totalLostRent"]
                    totalRenovation += unitExpenses["totalRenovation"]
    totalRevenue = totalFees + totalRent + totalOther
    totalExpense = totalRepairs + totalLostRent + totalRenovation + totalOtherExpenses
    totalNet = totalRevenue - totalExpense
    date = datetime.now()
    reportPayload = {
        "id": f"{currentYear}-{currentMonth}-{entityType}-{entityID}",
        "yearlyReportId": f"{currentYear}-{entityType}-{entityID}",
        "status": "Closed" if close == "Closed" else "InProgress",
        "entityType": entityType,
        "entityID": entityID,
        "rentRevenue": Decimal(totalRent),
        "feesRevenue": Decimal(totalFees),
        "otherRevenue": Decimal(totalOther),
        "totalRevenue": Decimal(totalRevenue),
        "repairsExpenses": Decimal(totalLostRent),
        "lostRentExpenses": Decimal(totalRepairs),
        "renovationExpenses": Decimal(totalRenovation),
        "otherExpenses": Decimal(totalOtherExpenses),
        "totalExpenses": Decimal(totalExpense),
        "net": Decimal(totalNet),
        "numOccupied": numOccupied,
        "numVacant": numVacant,
        "numRenovation": numRenovation,
        "month": currentMonth,
        "year": currentYear,
        "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
        "createdAt": (
            datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z")
            if not shouldUpdate
            else monthlyReport["createdAt"]
        ),
    }
    if shouldUpdate:
        deleteMonthlyReport = delete_monthly_report(monthlyReport["id"])
        updatedMonthlyReport = add_monthly_report(reportPayload)
    else:
        newMonthlyReport = add_monthly_report(reportPayload)
    return reportPayload


def getTotalExpenses(entityType, entityID, month, year):
    totalFees = Decimal(0)
    totalOther = Decimal(0)
    totalLostRent = Decimal(0)
    totalRenovation = Decimal(0)
    totalRepairs = Decimal(0)
    totalOtherExpenses = Decimal(0)
    requestList = get_service_request_list(entityType=entityType, entityID=entityID)
    for r in range(0, len(requestList)):
        request = requestList[r]
        requestCreatedDate = datetime.fromtimestamp(
            float(request["dateCreated"]) / 1000.0
        )
        if (
            (int(requestCreatedDate.month) == int(month))
            and (int(requestCreatedDate.year) == int(year))
            and ("finalCost" in request)
        ):
            if request["type"] == "Repairs":
                totalRepairs += Decimal(request["finalCost"])
            elif request["type"] == "Lost_Rent":
                totalLostRent += Decimal(request["finalCost"])
            elif request["type"] == "Renovation":
                totalRenovation += Decimal(request["finalCost"])
            elif request["type"] == "Fees_Charges":
                totalFees += Decimal(request["finalCost"])
            elif request["type"] == "Other_revenue":
                totalOther += Decimal(request["finalCost"])
            elif request["type"] == "Other_expenses":
                totalOtherExpenses += Decimal(request["finalCost"])
    totalExpenses = totalLostRent + totalRepairs + totalRenovation + totalOtherExpenses
    return {
        "totalFees": totalFees,
        "totalOther": totalOther,
        "totalOtherExpenses": totalOtherExpenses,
        "totalLostRent": totalLostRent,
        "totalRepairs": totalRepairs,
        "totalRenovation": totalRenovation,
        "totalExpenses": totalExpenses,
    }


# Route to generate and return a new unique organization ID
@app.route("/api/v1/generate_organization_id", methods=["GET"])
def generate_organization_id():
    new_organization_id = str(uuid.uuid4())  # Generate a new UUID

    # Extract name from query parameters
    name = request.args.get("name", default="Anonymous")
    print(name)

    # Create a dateCreated variable
    date_created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Create data dictionary to be pushed to Firestore
    data = {
        "organizationId": new_organization_id,
        "name": name,
        "dateCreated": date_created,
    }

    print(data)

    # Push data to Firestore
    push_to_DB("Organizations", new_organization_id, data)

    return jsonify(
        {
            "organizationId": new_organization_id,
            "name": name,
            "dateCreated": date_created,
        }
    )


# Function to push data to Firestore
def push_to_DB(collection_id, document_id, data):
    try:
        print("pushing to db")
        # Replace these values with your Firestore project details
        global project_id
        api_key = "YOUR_API_KEY"  # Replace with your Firestore API key

        # URL for the Firestore REST API
        url_base = f"https://firestore.googleapis.com/v1/projects/{project_id}/databases/(default)/documents/{collection_id}"

        # Ensure data is a dictionary
        if not isinstance(data, dict):
            raise ValueError("Data must be a dictionary")

        # Prepare the data to be posted to Firestore dynamically
        firestore_data = {"fields": {}}

        for key, value in data.items():
            field_type = determine_field_type(value)
            firestore_data["fields"][key] = {
                field_type: convert_to_firestore_value(value)
            }

        # Convert the data to JSON
        firestore_data_json = json.dumps(firestore_data)

        # Make a PATCH request to Firestore to post the data
        document_url = f"{url_base}/{document_id}?key={api_key}"
        response = requests.patch(
            document_url,
            data=firestore_data_json,
            headers={"Content-Type": "application/json"},
        )

        # Check the response
        if response.status_code == 200:
            print(f"Data posted to Firestore successfully.")
        else:
            print(
                f"Failed to post data to Firestore. Status code: {response.status_code}"
            )
            print(response.text)
    except Exception as e:
        print(f"Error: {str(e)}")


def determine_field_type(value):
    if isinstance(value, int):
        return "integerValue"
    elif isinstance(value, Decimal):
        return "doubleValue"
    elif isinstance(value, str):
        return "stringValue"
    elif isinstance(value, list):
        return "arrayValue"
    elif isinstance(value, dict):
        return "mapValue"
    else:
        raise ValueError(f"Unsupported data type: {type(value)}")


def convert_to_firestore_value(value):
    if isinstance(value, list):
        return {
            "arrayValue": {
                "values": [convert_to_firestore_value(item) for item in value]
            }
        }
    elif isinstance(value, dict):
        return {
            "mapValue": {
                "fields": {
                    key: {determine_field_type(v): convert_to_firestore_value(v)}
                    for key, v in value.items()
                }
            }
        }
    else:
        return value



@app.route('/upload_csv', methods=['POST'])
def upload_csv():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    if file:
        stream = StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = pd.read_csv(stream)  # Correct use of pandas read_csv
        grouped = csv_input.groupby(['Date', 'Category']).sum().reset_index()
        return render_template('report.html', data=grouped.to_dict(orient='records'))

@app.route("/read_csv")
def read_csv():
    # Simple route to display the HTML form for file upload
    return render_template('readCSV.html')


@app.route("/generate_pdf")
def generate_pdf():
    # Retrieve data from session
    data = session.get('data', [])  # Default to an empty list if no data
    if not data:
        return "No data available to generate PDF", 404
    html = render_template('report.html', data=data)
    pdf = HTML(string=html).write_pdf()
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'inline; filename=report.pdf'
    return response

if __name__ == "__main__":
    app.run(debug=True)
