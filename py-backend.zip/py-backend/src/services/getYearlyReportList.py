import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import *


# Boto Attr docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/customizations/dynamodb.html#boto3.dynamodb.conditions.Key
def get_yearly_report_list(year, entityType="", entityID=""):
    try:
        # Create a simple HTML page with an explanation of what Safety Scan does
        # Get the service resource.
        AWS_S3_CREDS = {
            "aws_access_key_id": "AKIA3HSN3MXEBW3FKWPY",  # os.getenv("AWS_ACCESS_KEY")
            "aws_secret_access_key": "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",  # os.getenv("AWS_SECRET_KEY")
        }
        dynamodb = boto3.resource("dynamodb", "us-east-2", **AWS_S3_CREDS)

        # Instantiate a table resource object without actually
        # creating a DynamoDB table. Note that the attributes of this table
        # are lazy-loaded: a request is not made nor are the attribute
        # values populated until the attributes
        # on the table resource are accessed or its load() method is called.
        table = dynamodb.Table("YearlyReportSummary-eyn6yvqoabdjnelzcyukkje5ga-main")
        filters = Attr("year").eq(year)
        if entityType:
            filters = filters & Attr("entityType").eq(entityType)
        if entityID:
            filters = filters & Attr("entityID").eq(entityID)
        # if (not entityID) or (not entityType):
        #     queryResponse = table.scan()
        #     reportDetails = queryResponse["Items"]
        #     return reportDetails

        queryResponse = table.scan(FilterExpression=filters)
        reportDetails = queryResponse["Items"]
        return reportDetails
    except Exception as exception:
        print(f"Error getting yearly report details {exception}")
        return {
            "error": exception,
            "confirmedRentRevenue": Decimal(0),
            "confirmedFeesRevenue": Decimal(0),
            "confirmedOtherRevenue": Decimal(0),
            "confirmedTotalRevenue": Decimal(0),
            "confirmedrepairsExpenses": Decimal(0),
            "confirmedLostRentExpenses": Decimal(0),
            "confirmedRenovationExpenses": Decimal(0),
            "confirmedOtherExpenses": Decimal(0),
            "confirmedtotalExpenses": Decimal(0),
        }
