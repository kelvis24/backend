/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type EntityFieldCreateFormInputValues = {
    entityID?: string;
    entityType?: string;
    type?: string;
    name?: string;
    value?: string;
};
export declare type EntityFieldCreateFormValidationValues = {
    entityID?: ValidationFunction<string>;
    entityType?: ValidationFunction<string>;
    type?: ValidationFunction<string>;
    name?: ValidationFunction<string>;
    value?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type EntityFieldCreateFormOverridesProps = {
    EntityFieldCreateFormGrid?: PrimitiveOverrideProps<GridProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    type?: PrimitiveOverrideProps<TextFieldProps>;
    name?: PrimitiveOverrideProps<TextFieldProps>;
    value?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type EntityFieldCreateFormProps = React.PropsWithChildren<{
    overrides?: EntityFieldCreateFormOverridesProps | undefined | null;
} & {
    clearOnSuccess?: boolean;
    onSubmit?: (fields: EntityFieldCreateFormInputValues) => EntityFieldCreateFormInputValues;
    onSuccess?: (fields: EntityFieldCreateFormInputValues) => void;
    onError?: (fields: EntityFieldCreateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: EntityFieldCreateFormInputValues) => EntityFieldCreateFormInputValues;
    onValidate?: EntityFieldCreateFormValidationValues;
} & React.CSSProperties>;
export default function EntityFieldCreateForm(props: EntityFieldCreateFormProps): React.ReactElement;
