/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type YearRecordsUpdateFormInputValues = {
    userID?: string;
    years?: string[];
};
export declare type YearRecordsUpdateFormValidationValues = {
    userID?: ValidationFunction<string>;
    years?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type YearRecordsUpdateFormOverridesProps = {
    YearRecordsUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    userID?: PrimitiveOverrideProps<TextFieldProps>;
    years?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type YearRecordsUpdateFormProps = React.PropsWithChildren<{
    overrides?: YearRecordsUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    yearRecords?: any;
    onSubmit?: (fields: YearRecordsUpdateFormInputValues) => YearRecordsUpdateFormInputValues;
    onSuccess?: (fields: YearRecordsUpdateFormInputValues) => void;
    onError?: (fields: YearRecordsUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: YearRecordsUpdateFormInputValues) => YearRecordsUpdateFormInputValues;
    onValidate?: YearRecordsUpdateFormValidationValues;
} & React.CSSProperties>;
export default function YearRecordsUpdateForm(props: YearRecordsUpdateFormProps): React.ReactElement;
