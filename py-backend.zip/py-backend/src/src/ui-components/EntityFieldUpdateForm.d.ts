/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type EntityFieldUpdateFormInputValues = {
    entityID?: string;
    entityType?: string;
    type?: string;
    name?: string;
    value?: string;
};
export declare type EntityFieldUpdateFormValidationValues = {
    entityID?: ValidationFunction<string>;
    entityType?: ValidationFunction<string>;
    type?: ValidationFunction<string>;
    name?: ValidationFunction<string>;
    value?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type EntityFieldUpdateFormOverridesProps = {
    EntityFieldUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    type?: PrimitiveOverrideProps<TextFieldProps>;
    name?: PrimitiveOverrideProps<TextFieldProps>;
    value?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type EntityFieldUpdateFormProps = React.PropsWithChildren<{
    overrides?: EntityFieldUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    entityField?: any;
    onSubmit?: (fields: EntityFieldUpdateFormInputValues) => EntityFieldUpdateFormInputValues;
    onSuccess?: (fields: EntityFieldUpdateFormInputValues) => void;
    onError?: (fields: EntityFieldUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: EntityFieldUpdateFormInputValues) => EntityFieldUpdateFormInputValues;
    onValidate?: EntityFieldUpdateFormValidationValues;
} & React.CSSProperties>;
export default function EntityFieldUpdateForm(props: EntityFieldUpdateFormProps): React.ReactElement;
