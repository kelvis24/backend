/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, SwitchFieldProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type AmenitiesCreateFormInputValues = {
    entityID?: string;
    entityType?: string;
    name?: string;
    areaSize?: string;
    type?: string;
    open?: boolean;
    charge?: number;
    availabilityDate?: string;
};
export declare type AmenitiesCreateFormValidationValues = {
    entityID?: ValidationFunction<string>;
    entityType?: ValidationFunction<string>;
    name?: ValidationFunction<string>;
    areaSize?: ValidationFunction<string>;
    type?: ValidationFunction<string>;
    open?: ValidationFunction<boolean>;
    charge?: ValidationFunction<number>;
    availabilityDate?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type AmenitiesCreateFormOverridesProps = {
    AmenitiesCreateFormGrid?: PrimitiveOverrideProps<GridProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    name?: PrimitiveOverrideProps<TextFieldProps>;
    areaSize?: PrimitiveOverrideProps<TextFieldProps>;
    type?: PrimitiveOverrideProps<TextFieldProps>;
    open?: PrimitiveOverrideProps<SwitchFieldProps>;
    charge?: PrimitiveOverrideProps<TextFieldProps>;
    availabilityDate?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type AmenitiesCreateFormProps = React.PropsWithChildren<{
    overrides?: AmenitiesCreateFormOverridesProps | undefined | null;
} & {
    clearOnSuccess?: boolean;
    onSubmit?: (fields: AmenitiesCreateFormInputValues) => AmenitiesCreateFormInputValues;
    onSuccess?: (fields: AmenitiesCreateFormInputValues) => void;
    onError?: (fields: AmenitiesCreateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: AmenitiesCreateFormInputValues) => AmenitiesCreateFormInputValues;
    onValidate?: AmenitiesCreateFormValidationValues;
} & React.CSSProperties>;
export default function AmenitiesCreateForm(props: AmenitiesCreateFormProps): React.ReactElement;
