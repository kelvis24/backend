/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { getComments } from "../graphql/queries";
import { updateComments } from "../graphql/mutations";
export default function CommentsUpdateForm(props) {
  const {
    id: idProp,
    comments: commentsModelProp,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    commenter: "",
    text: "",
    createdDate: "",
    parentID: "",
    type: "",
  };
  const [commenter, setCommenter] = React.useState(initialValues.commenter);
  const [text, setText] = React.useState(initialValues.text);
  const [createdDate, setCreatedDate] = React.useState(
    initialValues.createdDate
  );
  const [parentID, setParentID] = React.useState(initialValues.parentID);
  const [type, setType] = React.useState(initialValues.type);
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    const cleanValues = commentsRecord
      ? { ...initialValues, ...commentsRecord }
      : initialValues;
    setCommenter(cleanValues.commenter);
    setText(cleanValues.text);
    setCreatedDate(cleanValues.createdDate);
    setParentID(cleanValues.parentID);
    setType(cleanValues.type);
    setErrors({});
  };
  const [commentsRecord, setCommentsRecord] = React.useState(commentsModelProp);
  React.useEffect(() => {
    const queryData = async () => {
      const record = idProp
        ? (
            await API.graphql({
              query: getComments.replaceAll("__typename", ""),
              variables: { id: idProp },
            })
          )?.data?.getComments
        : commentsModelProp;
      setCommentsRecord(record);
    };
    queryData();
  }, [idProp, commentsModelProp]);
  React.useEffect(resetStateValues, [commentsRecord]);
  const validations = {
    commenter: [],
    text: [],
    createdDate: [],
    parentID: [],
    type: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          commenter: commenter ?? null,
          text: text ?? null,
          createdDate: createdDate ?? null,
          parentID: parentID ?? null,
          type: type ?? null,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: updateComments.replaceAll("__typename", ""),
            variables: {
              input: {
                id: commentsRecord.id,
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "CommentsUpdateForm")}
      {...rest}
    >
      <TextField
        label="Commenter"
        isRequired={false}
        isReadOnly={false}
        value={commenter}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              commenter: value,
              text,
              createdDate,
              parentID,
              type,
            };
            const result = onChange(modelFields);
            value = result?.commenter ?? value;
          }
          if (errors.commenter?.hasError) {
            runValidationTasks("commenter", value);
          }
          setCommenter(value);
        }}
        onBlur={() => runValidationTasks("commenter", commenter)}
        errorMessage={errors.commenter?.errorMessage}
        hasError={errors.commenter?.hasError}
        {...getOverrideProps(overrides, "commenter")}
      ></TextField>
      <TextField
        label="Text"
        isRequired={false}
        isReadOnly={false}
        value={text}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              commenter,
              text: value,
              createdDate,
              parentID,
              type,
            };
            const result = onChange(modelFields);
            value = result?.text ?? value;
          }
          if (errors.text?.hasError) {
            runValidationTasks("text", value);
          }
          setText(value);
        }}
        onBlur={() => runValidationTasks("text", text)}
        errorMessage={errors.text?.errorMessage}
        hasError={errors.text?.hasError}
        {...getOverrideProps(overrides, "text")}
      ></TextField>
      <TextField
        label="Created date"
        isRequired={false}
        isReadOnly={false}
        value={createdDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              commenter,
              text,
              createdDate: value,
              parentID,
              type,
            };
            const result = onChange(modelFields);
            value = result?.createdDate ?? value;
          }
          if (errors.createdDate?.hasError) {
            runValidationTasks("createdDate", value);
          }
          setCreatedDate(value);
        }}
        onBlur={() => runValidationTasks("createdDate", createdDate)}
        errorMessage={errors.createdDate?.errorMessage}
        hasError={errors.createdDate?.hasError}
        {...getOverrideProps(overrides, "createdDate")}
      ></TextField>
      <TextField
        label="Parent id"
        isRequired={false}
        isReadOnly={false}
        value={parentID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              commenter,
              text,
              createdDate,
              parentID: value,
              type,
            };
            const result = onChange(modelFields);
            value = result?.parentID ?? value;
          }
          if (errors.parentID?.hasError) {
            runValidationTasks("parentID", value);
          }
          setParentID(value);
        }}
        onBlur={() => runValidationTasks("parentID", parentID)}
        errorMessage={errors.parentID?.errorMessage}
        hasError={errors.parentID?.hasError}
        {...getOverrideProps(overrides, "parentID")}
      ></TextField>
      <TextField
        label="Type"
        isRequired={false}
        isReadOnly={false}
        value={type}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              commenter,
              text,
              createdDate,
              parentID,
              type: value,
            };
            const result = onChange(modelFields);
            value = result?.type ?? value;
          }
          if (errors.type?.hasError) {
            runValidationTasks("type", value);
          }
          setType(value);
        }}
        onBlur={() => runValidationTasks("type", type)}
        errorMessage={errors.type?.errorMessage}
        hasError={errors.type?.hasError}
        {...getOverrideProps(overrides, "type")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Reset"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          isDisabled={!(idProp || commentsModelProp)}
          {...getOverrideProps(overrides, "ResetButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={
              !(idProp || commentsModelProp) ||
              Object.values(errors).some((e) => e?.hasError)
            }
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
