/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type YearlyReportSummaryUpdateFormInputValues = {
    entityID?: string;
    entityType?: string;
    rentRevenue?: number;
    feesRevenue?: number;
    otherRevenue?: number;
    totalRevenue?: number;
    repairsExpenses?: number;
    lostRentExpenses?: number;
    renovationExpenses?: number;
    otherExpenses?: number;
    totalExpenses?: number;
    status?: string;
    net?: number;
    numOccupied?: number;
    numVacant?: number;
    numRenovation?: number;
    year?: string;
    confirmedRentRevenue?: number;
    confirmedFeesRevenue?: number;
    confirmedOtherRevenue?: number;
    confirmedTotalRevenue?: number;
    confirmedrepairsExpenses?: number;
    confirmedLostRentExpenses?: number;
    confirmedRenovationExpenses?: number;
    confirmedOtherExpenses?: number;
    confirmedtotalExpenses?: number;
};
export declare type YearlyReportSummaryUpdateFormValidationValues = {
    entityID?: ValidationFunction<string>;
    entityType?: ValidationFunction<string>;
    rentRevenue?: ValidationFunction<number>;
    feesRevenue?: ValidationFunction<number>;
    otherRevenue?: ValidationFunction<number>;
    totalRevenue?: ValidationFunction<number>;
    repairsExpenses?: ValidationFunction<number>;
    lostRentExpenses?: ValidationFunction<number>;
    renovationExpenses?: ValidationFunction<number>;
    otherExpenses?: ValidationFunction<number>;
    totalExpenses?: ValidationFunction<number>;
    status?: ValidationFunction<string>;
    net?: ValidationFunction<number>;
    numOccupied?: ValidationFunction<number>;
    numVacant?: ValidationFunction<number>;
    numRenovation?: ValidationFunction<number>;
    year?: ValidationFunction<string>;
    confirmedRentRevenue?: ValidationFunction<number>;
    confirmedFeesRevenue?: ValidationFunction<number>;
    confirmedOtherRevenue?: ValidationFunction<number>;
    confirmedTotalRevenue?: ValidationFunction<number>;
    confirmedrepairsExpenses?: ValidationFunction<number>;
    confirmedLostRentExpenses?: ValidationFunction<number>;
    confirmedRenovationExpenses?: ValidationFunction<number>;
    confirmedOtherExpenses?: ValidationFunction<number>;
    confirmedtotalExpenses?: ValidationFunction<number>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type YearlyReportSummaryUpdateFormOverridesProps = {
    YearlyReportSummaryUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    rentRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    feesRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    otherRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    totalRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    repairsExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    lostRentExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    renovationExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    otherExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    totalExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    status?: PrimitiveOverrideProps<TextFieldProps>;
    net?: PrimitiveOverrideProps<TextFieldProps>;
    numOccupied?: PrimitiveOverrideProps<TextFieldProps>;
    numVacant?: PrimitiveOverrideProps<TextFieldProps>;
    numRenovation?: PrimitiveOverrideProps<TextFieldProps>;
    year?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedRentRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedFeesRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedOtherRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedTotalRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedrepairsExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedLostRentExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedRenovationExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedOtherExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    confirmedtotalExpenses?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type YearlyReportSummaryUpdateFormProps = React.PropsWithChildren<{
    overrides?: YearlyReportSummaryUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    yearlyReportSummary?: any;
    onSubmit?: (fields: YearlyReportSummaryUpdateFormInputValues) => YearlyReportSummaryUpdateFormInputValues;
    onSuccess?: (fields: YearlyReportSummaryUpdateFormInputValues) => void;
    onError?: (fields: YearlyReportSummaryUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: YearlyReportSummaryUpdateFormInputValues) => YearlyReportSummaryUpdateFormInputValues;
    onValidate?: YearlyReportSummaryUpdateFormValidationValues;
} & React.CSSProperties>;
export default function YearlyReportSummaryUpdateForm(props: YearlyReportSummaryUpdateFormProps): React.ReactElement;
