/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { createUnit } from "../graphql/mutations";
export default function UnitCreateForm(props) {
  const {
    clearOnSuccess = true,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    status: "",
    description: "",
    name: "",
    rent: "",
    price: "",
    numBedroom: "",
    numBathroom: "",
    availabilityDate: "",
    expectedRentPaymentDate: "",
    type: "",
    size: "",
    street: "",
    buildingID: "",
    tenantID: "",
    contact: "",
    userID: "",
    organizationID: "",
  };
  const [status, setStatus] = React.useState(initialValues.status);
  const [description, setDescription] = React.useState(
    initialValues.description
  );
  const [name, setName] = React.useState(initialValues.name);
  const [rent, setRent] = React.useState(initialValues.rent);
  const [price, setPrice] = React.useState(initialValues.price);
  const [numBedroom, setNumBedroom] = React.useState(initialValues.numBedroom);
  const [numBathroom, setNumBathroom] = React.useState(
    initialValues.numBathroom
  );
  const [availabilityDate, setAvailabilityDate] = React.useState(
    initialValues.availabilityDate
  );
  const [expectedRentPaymentDate, setExpectedRentPaymentDate] = React.useState(
    initialValues.expectedRentPaymentDate
  );
  const [type, setType] = React.useState(initialValues.type);
  const [size, setSize] = React.useState(initialValues.size);
  const [street, setStreet] = React.useState(initialValues.street);
  const [buildingID, setBuildingID] = React.useState(initialValues.buildingID);
  const [tenantID, setTenantID] = React.useState(initialValues.tenantID);
  const [contact, setContact] = React.useState(initialValues.contact);
  const [userID, setUserID] = React.useState(initialValues.userID);
  const [organizationID, setOrganizationID] = React.useState(
    initialValues.organizationID
  );
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    setStatus(initialValues.status);
    setDescription(initialValues.description);
    setName(initialValues.name);
    setRent(initialValues.rent);
    setPrice(initialValues.price);
    setNumBedroom(initialValues.numBedroom);
    setNumBathroom(initialValues.numBathroom);
    setAvailabilityDate(initialValues.availabilityDate);
    setExpectedRentPaymentDate(initialValues.expectedRentPaymentDate);
    setType(initialValues.type);
    setSize(initialValues.size);
    setStreet(initialValues.street);
    setBuildingID(initialValues.buildingID);
    setTenantID(initialValues.tenantID);
    setContact(initialValues.contact);
    setUserID(initialValues.userID);
    setOrganizationID(initialValues.organizationID);
    setErrors({});
  };
  const validations = {
    status: [],
    description: [],
    name: [],
    rent: [],
    price: [],
    numBedroom: [],
    numBathroom: [],
    availabilityDate: [],
    expectedRentPaymentDate: [],
    type: [],
    size: [],
    street: [],
    buildingID: [],
    tenantID: [],
    contact: [],
    userID: [],
    organizationID: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          status,
          description,
          name,
          rent,
          price,
          numBedroom,
          numBathroom,
          availabilityDate,
          expectedRentPaymentDate,
          type,
          size,
          street,
          buildingID,
          tenantID,
          contact,
          userID,
          organizationID,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: createUnit.replaceAll("__typename", ""),
            variables: {
              input: {
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
          if (clearOnSuccess) {
            resetStateValues();
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "UnitCreateForm")}
      {...rest}
    >
      <TextField
        label="Status"
        isRequired={false}
        isReadOnly={false}
        value={status}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status: value,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.status ?? value;
          }
          if (errors.status?.hasError) {
            runValidationTasks("status", value);
          }
          setStatus(value);
        }}
        onBlur={() => runValidationTasks("status", status)}
        errorMessage={errors.status?.errorMessage}
        hasError={errors.status?.hasError}
        {...getOverrideProps(overrides, "status")}
      ></TextField>
      <TextField
        label="Description"
        isRequired={false}
        isReadOnly={false}
        value={description}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description: value,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.description ?? value;
          }
          if (errors.description?.hasError) {
            runValidationTasks("description", value);
          }
          setDescription(value);
        }}
        onBlur={() => runValidationTasks("description", description)}
        errorMessage={errors.description?.errorMessage}
        hasError={errors.description?.hasError}
        {...getOverrideProps(overrides, "description")}
      ></TextField>
      <TextField
        label="Name"
        isRequired={false}
        isReadOnly={false}
        value={name}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name: value,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.name ?? value;
          }
          if (errors.name?.hasError) {
            runValidationTasks("name", value);
          }
          setName(value);
        }}
        onBlur={() => runValidationTasks("name", name)}
        errorMessage={errors.name?.errorMessage}
        hasError={errors.name?.hasError}
        {...getOverrideProps(overrides, "name")}
      ></TextField>
      <TextField
        label="Rent"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={rent}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent: value,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.rent ?? value;
          }
          if (errors.rent?.hasError) {
            runValidationTasks("rent", value);
          }
          setRent(value);
        }}
        onBlur={() => runValidationTasks("rent", rent)}
        errorMessage={errors.rent?.errorMessage}
        hasError={errors.rent?.hasError}
        {...getOverrideProps(overrides, "rent")}
      ></TextField>
      <TextField
        label="Price"
        isRequired={false}
        isReadOnly={false}
        value={price}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price: value,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.price ?? value;
          }
          if (errors.price?.hasError) {
            runValidationTasks("price", value);
          }
          setPrice(value);
        }}
        onBlur={() => runValidationTasks("price", price)}
        errorMessage={errors.price?.errorMessage}
        hasError={errors.price?.hasError}
        {...getOverrideProps(overrides, "price")}
      ></TextField>
      <TextField
        label="Num bedroom"
        isRequired={false}
        isReadOnly={false}
        value={numBedroom}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom: value,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.numBedroom ?? value;
          }
          if (errors.numBedroom?.hasError) {
            runValidationTasks("numBedroom", value);
          }
          setNumBedroom(value);
        }}
        onBlur={() => runValidationTasks("numBedroom", numBedroom)}
        errorMessage={errors.numBedroom?.errorMessage}
        hasError={errors.numBedroom?.hasError}
        {...getOverrideProps(overrides, "numBedroom")}
      ></TextField>
      <TextField
        label="Num bathroom"
        isRequired={false}
        isReadOnly={false}
        value={numBathroom}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom: value,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.numBathroom ?? value;
          }
          if (errors.numBathroom?.hasError) {
            runValidationTasks("numBathroom", value);
          }
          setNumBathroom(value);
        }}
        onBlur={() => runValidationTasks("numBathroom", numBathroom)}
        errorMessage={errors.numBathroom?.errorMessage}
        hasError={errors.numBathroom?.hasError}
        {...getOverrideProps(overrides, "numBathroom")}
      ></TextField>
      <TextField
        label="Availability date"
        isRequired={false}
        isReadOnly={false}
        value={availabilityDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate: value,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.availabilityDate ?? value;
          }
          if (errors.availabilityDate?.hasError) {
            runValidationTasks("availabilityDate", value);
          }
          setAvailabilityDate(value);
        }}
        onBlur={() => runValidationTasks("availabilityDate", availabilityDate)}
        errorMessage={errors.availabilityDate?.errorMessage}
        hasError={errors.availabilityDate?.hasError}
        {...getOverrideProps(overrides, "availabilityDate")}
      ></TextField>
      <TextField
        label="Expected rent payment date"
        isRequired={false}
        isReadOnly={false}
        value={expectedRentPaymentDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate: value,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.expectedRentPaymentDate ?? value;
          }
          if (errors.expectedRentPaymentDate?.hasError) {
            runValidationTasks("expectedRentPaymentDate", value);
          }
          setExpectedRentPaymentDate(value);
        }}
        onBlur={() =>
          runValidationTasks("expectedRentPaymentDate", expectedRentPaymentDate)
        }
        errorMessage={errors.expectedRentPaymentDate?.errorMessage}
        hasError={errors.expectedRentPaymentDate?.hasError}
        {...getOverrideProps(overrides, "expectedRentPaymentDate")}
      ></TextField>
      <TextField
        label="Type"
        isRequired={false}
        isReadOnly={false}
        value={type}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type: value,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.type ?? value;
          }
          if (errors.type?.hasError) {
            runValidationTasks("type", value);
          }
          setType(value);
        }}
        onBlur={() => runValidationTasks("type", type)}
        errorMessage={errors.type?.errorMessage}
        hasError={errors.type?.hasError}
        {...getOverrideProps(overrides, "type")}
      ></TextField>
      <TextField
        label="Size"
        isRequired={false}
        isReadOnly={false}
        value={size}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size: value,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.size ?? value;
          }
          if (errors.size?.hasError) {
            runValidationTasks("size", value);
          }
          setSize(value);
        }}
        onBlur={() => runValidationTasks("size", size)}
        errorMessage={errors.size?.errorMessage}
        hasError={errors.size?.hasError}
        {...getOverrideProps(overrides, "size")}
      ></TextField>
      <TextField
        label="Street"
        isRequired={false}
        isReadOnly={false}
        value={street}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street: value,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.street ?? value;
          }
          if (errors.street?.hasError) {
            runValidationTasks("street", value);
          }
          setStreet(value);
        }}
        onBlur={() => runValidationTasks("street", street)}
        errorMessage={errors.street?.errorMessage}
        hasError={errors.street?.hasError}
        {...getOverrideProps(overrides, "street")}
      ></TextField>
      <TextField
        label="Building id"
        isRequired={false}
        isReadOnly={false}
        value={buildingID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID: value,
              tenantID,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.buildingID ?? value;
          }
          if (errors.buildingID?.hasError) {
            runValidationTasks("buildingID", value);
          }
          setBuildingID(value);
        }}
        onBlur={() => runValidationTasks("buildingID", buildingID)}
        errorMessage={errors.buildingID?.errorMessage}
        hasError={errors.buildingID?.hasError}
        {...getOverrideProps(overrides, "buildingID")}
      ></TextField>
      <TextField
        label="Tenant id"
        isRequired={false}
        isReadOnly={false}
        value={tenantID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID: value,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.tenantID ?? value;
          }
          if (errors.tenantID?.hasError) {
            runValidationTasks("tenantID", value);
          }
          setTenantID(value);
        }}
        onBlur={() => runValidationTasks("tenantID", tenantID)}
        errorMessage={errors.tenantID?.errorMessage}
        hasError={errors.tenantID?.hasError}
        {...getOverrideProps(overrides, "tenantID")}
      ></TextField>
      <TextField
        label="Contact"
        isRequired={false}
        isReadOnly={false}
        value={contact}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact: value,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.contact ?? value;
          }
          if (errors.contact?.hasError) {
            runValidationTasks("contact", value);
          }
          setContact(value);
        }}
        onBlur={() => runValidationTasks("contact", contact)}
        errorMessage={errors.contact?.errorMessage}
        hasError={errors.contact?.hasError}
        {...getOverrideProps(overrides, "contact")}
      ></TextField>
      <TextField
        label="User id"
        isRequired={false}
        isReadOnly={false}
        value={userID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID: value,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.userID ?? value;
          }
          if (errors.userID?.hasError) {
            runValidationTasks("userID", value);
          }
          setUserID(value);
        }}
        onBlur={() => runValidationTasks("userID", userID)}
        errorMessage={errors.userID?.errorMessage}
        hasError={errors.userID?.hasError}
        {...getOverrideProps(overrides, "userID")}
      ></TextField>
      <TextField
        label="Organization id"
        isRequired={false}
        isReadOnly={false}
        value={organizationID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              availabilityDate,
              expectedRentPaymentDate,
              type,
              size,
              street,
              buildingID,
              tenantID,
              contact,
              userID,
              organizationID: value,
            };
            const result = onChange(modelFields);
            value = result?.organizationID ?? value;
          }
          if (errors.organizationID?.hasError) {
            runValidationTasks("organizationID", value);
          }
          setOrganizationID(value);
        }}
        onBlur={() => runValidationTasks("organizationID", organizationID)}
        errorMessage={errors.organizationID?.errorMessage}
        hasError={errors.organizationID?.hasError}
        {...getOverrideProps(overrides, "organizationID")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Clear"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          {...getOverrideProps(overrides, "ClearButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={Object.values(errors).some((e) => e?.hasError)}
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
