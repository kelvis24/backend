/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { getServiceRequest } from "../graphql/queries";
import { updateServiceRequest } from "../graphql/mutations";
export default function ServiceRequestUpdateForm(props) {
  const {
    id: idProp,
    serviceRequest: serviceRequestModelProp,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    creatorID: "",
    creatorName: "",
    handlerID: "",
    handlerName: "",
    watcherID: "",
    watcherName: "",
    tenantID: "",
    tenantName: "",
    contractor: "",
    entityID: "",
    entityType: "",
    dateCreated: "",
    dateUpdated: "",
    status: "",
    description: "",
    title: "",
    organizationID: "",
    estimatedCost: "",
    finalCost: "",
    type: "",
  };
  const [creatorID, setCreatorID] = React.useState(initialValues.creatorID);
  const [creatorName, setCreatorName] = React.useState(
    initialValues.creatorName
  );
  const [handlerID, setHandlerID] = React.useState(initialValues.handlerID);
  const [handlerName, setHandlerName] = React.useState(
    initialValues.handlerName
  );
  const [watcherID, setWatcherID] = React.useState(initialValues.watcherID);
  const [watcherName, setWatcherName] = React.useState(
    initialValues.watcherName
  );
  const [tenantID, setTenantID] = React.useState(initialValues.tenantID);
  const [tenantName, setTenantName] = React.useState(initialValues.tenantName);
  const [contractor, setContractor] = React.useState(initialValues.contractor);
  const [entityID, setEntityID] = React.useState(initialValues.entityID);
  const [entityType, setEntityType] = React.useState(initialValues.entityType);
  const [dateCreated, setDateCreated] = React.useState(
    initialValues.dateCreated
  );
  const [dateUpdated, setDateUpdated] = React.useState(
    initialValues.dateUpdated
  );
  const [status, setStatus] = React.useState(initialValues.status);
  const [description, setDescription] = React.useState(
    initialValues.description
  );
  const [title, setTitle] = React.useState(initialValues.title);
  const [organizationID, setOrganizationID] = React.useState(
    initialValues.organizationID
  );
  const [estimatedCost, setEstimatedCost] = React.useState(
    initialValues.estimatedCost
  );
  const [finalCost, setFinalCost] = React.useState(initialValues.finalCost);
  const [type, setType] = React.useState(initialValues.type);
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    const cleanValues = serviceRequestRecord
      ? { ...initialValues, ...serviceRequestRecord }
      : initialValues;
    setCreatorID(cleanValues.creatorID);
    setCreatorName(cleanValues.creatorName);
    setHandlerID(cleanValues.handlerID);
    setHandlerName(cleanValues.handlerName);
    setWatcherID(cleanValues.watcherID);
    setWatcherName(cleanValues.watcherName);
    setTenantID(cleanValues.tenantID);
    setTenantName(cleanValues.tenantName);
    setContractor(cleanValues.contractor);
    setEntityID(cleanValues.entityID);
    setEntityType(cleanValues.entityType);
    setDateCreated(cleanValues.dateCreated);
    setDateUpdated(cleanValues.dateUpdated);
    setStatus(cleanValues.status);
    setDescription(cleanValues.description);
    setTitle(cleanValues.title);
    setOrganizationID(cleanValues.organizationID);
    setEstimatedCost(cleanValues.estimatedCost);
    setFinalCost(cleanValues.finalCost);
    setType(cleanValues.type);
    setErrors({});
  };
  const [serviceRequestRecord, setServiceRequestRecord] = React.useState(
    serviceRequestModelProp
  );
  React.useEffect(() => {
    const queryData = async () => {
      const record = idProp
        ? (
            await API.graphql({
              query: getServiceRequest.replaceAll("__typename", ""),
              variables: { id: idProp },
            })
          )?.data?.getServiceRequest
        : serviceRequestModelProp;
      setServiceRequestRecord(record);
    };
    queryData();
  }, [idProp, serviceRequestModelProp]);
  React.useEffect(resetStateValues, [serviceRequestRecord]);
  const validations = {
    creatorID: [],
    creatorName: [],
    handlerID: [],
    handlerName: [],
    watcherID: [],
    watcherName: [],
    tenantID: [],
    tenantName: [],
    contractor: [],
    entityID: [],
    entityType: [],
    dateCreated: [],
    dateUpdated: [],
    status: [],
    description: [],
    title: [],
    organizationID: [],
    estimatedCost: [],
    finalCost: [],
    type: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          creatorID: creatorID ?? null,
          creatorName: creatorName ?? null,
          handlerID: handlerID ?? null,
          handlerName: handlerName ?? null,
          watcherID: watcherID ?? null,
          watcherName: watcherName ?? null,
          tenantID: tenantID ?? null,
          tenantName: tenantName ?? null,
          contractor: contractor ?? null,
          entityID: entityID ?? null,
          entityType: entityType ?? null,
          dateCreated: dateCreated ?? null,
          dateUpdated: dateUpdated ?? null,
          status: status ?? null,
          description: description ?? null,
          title: title ?? null,
          organizationID: organizationID ?? null,
          estimatedCost: estimatedCost ?? null,
          finalCost: finalCost ?? null,
          type: type ?? null,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: updateServiceRequest.replaceAll("__typename", ""),
            variables: {
              input: {
                id: serviceRequestRecord.id,
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "ServiceRequestUpdateForm")}
      {...rest}
    >
      <TextField
        label="Creator id"
        isRequired={false}
        isReadOnly={false}
        value={creatorID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID: value,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.creatorID ?? value;
          }
          if (errors.creatorID?.hasError) {
            runValidationTasks("creatorID", value);
          }
          setCreatorID(value);
        }}
        onBlur={() => runValidationTasks("creatorID", creatorID)}
        errorMessage={errors.creatorID?.errorMessage}
        hasError={errors.creatorID?.hasError}
        {...getOverrideProps(overrides, "creatorID")}
      ></TextField>
      <TextField
        label="Creator name"
        isRequired={false}
        isReadOnly={false}
        value={creatorName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName: value,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.creatorName ?? value;
          }
          if (errors.creatorName?.hasError) {
            runValidationTasks("creatorName", value);
          }
          setCreatorName(value);
        }}
        onBlur={() => runValidationTasks("creatorName", creatorName)}
        errorMessage={errors.creatorName?.errorMessage}
        hasError={errors.creatorName?.hasError}
        {...getOverrideProps(overrides, "creatorName")}
      ></TextField>
      <TextField
        label="Handler id"
        isRequired={false}
        isReadOnly={false}
        value={handlerID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID: value,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.handlerID ?? value;
          }
          if (errors.handlerID?.hasError) {
            runValidationTasks("handlerID", value);
          }
          setHandlerID(value);
        }}
        onBlur={() => runValidationTasks("handlerID", handlerID)}
        errorMessage={errors.handlerID?.errorMessage}
        hasError={errors.handlerID?.hasError}
        {...getOverrideProps(overrides, "handlerID")}
      ></TextField>
      <TextField
        label="Handler name"
        isRequired={false}
        isReadOnly={false}
        value={handlerName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName: value,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.handlerName ?? value;
          }
          if (errors.handlerName?.hasError) {
            runValidationTasks("handlerName", value);
          }
          setHandlerName(value);
        }}
        onBlur={() => runValidationTasks("handlerName", handlerName)}
        errorMessage={errors.handlerName?.errorMessage}
        hasError={errors.handlerName?.hasError}
        {...getOverrideProps(overrides, "handlerName")}
      ></TextField>
      <TextField
        label="Watcher id"
        isRequired={false}
        isReadOnly={false}
        value={watcherID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID: value,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.watcherID ?? value;
          }
          if (errors.watcherID?.hasError) {
            runValidationTasks("watcherID", value);
          }
          setWatcherID(value);
        }}
        onBlur={() => runValidationTasks("watcherID", watcherID)}
        errorMessage={errors.watcherID?.errorMessage}
        hasError={errors.watcherID?.hasError}
        {...getOverrideProps(overrides, "watcherID")}
      ></TextField>
      <TextField
        label="Watcher name"
        isRequired={false}
        isReadOnly={false}
        value={watcherName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName: value,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.watcherName ?? value;
          }
          if (errors.watcherName?.hasError) {
            runValidationTasks("watcherName", value);
          }
          setWatcherName(value);
        }}
        onBlur={() => runValidationTasks("watcherName", watcherName)}
        errorMessage={errors.watcherName?.errorMessage}
        hasError={errors.watcherName?.hasError}
        {...getOverrideProps(overrides, "watcherName")}
      ></TextField>
      <TextField
        label="Tenant id"
        isRequired={false}
        isReadOnly={false}
        value={tenantID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID: value,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.tenantID ?? value;
          }
          if (errors.tenantID?.hasError) {
            runValidationTasks("tenantID", value);
          }
          setTenantID(value);
        }}
        onBlur={() => runValidationTasks("tenantID", tenantID)}
        errorMessage={errors.tenantID?.errorMessage}
        hasError={errors.tenantID?.hasError}
        {...getOverrideProps(overrides, "tenantID")}
      ></TextField>
      <TextField
        label="Tenant name"
        isRequired={false}
        isReadOnly={false}
        value={tenantName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName: value,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.tenantName ?? value;
          }
          if (errors.tenantName?.hasError) {
            runValidationTasks("tenantName", value);
          }
          setTenantName(value);
        }}
        onBlur={() => runValidationTasks("tenantName", tenantName)}
        errorMessage={errors.tenantName?.errorMessage}
        hasError={errors.tenantName?.hasError}
        {...getOverrideProps(overrides, "tenantName")}
      ></TextField>
      <TextField
        label="Contractor"
        isRequired={false}
        isReadOnly={false}
        value={contractor}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor: value,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.contractor ?? value;
          }
          if (errors.contractor?.hasError) {
            runValidationTasks("contractor", value);
          }
          setContractor(value);
        }}
        onBlur={() => runValidationTasks("contractor", contractor)}
        errorMessage={errors.contractor?.errorMessage}
        hasError={errors.contractor?.hasError}
        {...getOverrideProps(overrides, "contractor")}
      ></TextField>
      <TextField
        label="Entity id"
        isRequired={false}
        isReadOnly={false}
        value={entityID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID: value,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.entityID ?? value;
          }
          if (errors.entityID?.hasError) {
            runValidationTasks("entityID", value);
          }
          setEntityID(value);
        }}
        onBlur={() => runValidationTasks("entityID", entityID)}
        errorMessage={errors.entityID?.errorMessage}
        hasError={errors.entityID?.hasError}
        {...getOverrideProps(overrides, "entityID")}
      ></TextField>
      <TextField
        label="Entity type"
        isRequired={false}
        isReadOnly={false}
        value={entityType}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType: value,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.entityType ?? value;
          }
          if (errors.entityType?.hasError) {
            runValidationTasks("entityType", value);
          }
          setEntityType(value);
        }}
        onBlur={() => runValidationTasks("entityType", entityType)}
        errorMessage={errors.entityType?.errorMessage}
        hasError={errors.entityType?.hasError}
        {...getOverrideProps(overrides, "entityType")}
      ></TextField>
      <TextField
        label="Date created"
        isRequired={false}
        isReadOnly={false}
        value={dateCreated}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated: value,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.dateCreated ?? value;
          }
          if (errors.dateCreated?.hasError) {
            runValidationTasks("dateCreated", value);
          }
          setDateCreated(value);
        }}
        onBlur={() => runValidationTasks("dateCreated", dateCreated)}
        errorMessage={errors.dateCreated?.errorMessage}
        hasError={errors.dateCreated?.hasError}
        {...getOverrideProps(overrides, "dateCreated")}
      ></TextField>
      <TextField
        label="Date updated"
        isRequired={false}
        isReadOnly={false}
        value={dateUpdated}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated: value,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.dateUpdated ?? value;
          }
          if (errors.dateUpdated?.hasError) {
            runValidationTasks("dateUpdated", value);
          }
          setDateUpdated(value);
        }}
        onBlur={() => runValidationTasks("dateUpdated", dateUpdated)}
        errorMessage={errors.dateUpdated?.errorMessage}
        hasError={errors.dateUpdated?.hasError}
        {...getOverrideProps(overrides, "dateUpdated")}
      ></TextField>
      <TextField
        label="Status"
        isRequired={false}
        isReadOnly={false}
        value={status}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status: value,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.status ?? value;
          }
          if (errors.status?.hasError) {
            runValidationTasks("status", value);
          }
          setStatus(value);
        }}
        onBlur={() => runValidationTasks("status", status)}
        errorMessage={errors.status?.errorMessage}
        hasError={errors.status?.hasError}
        {...getOverrideProps(overrides, "status")}
      ></TextField>
      <TextField
        label="Description"
        isRequired={false}
        isReadOnly={false}
        value={description}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description: value,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.description ?? value;
          }
          if (errors.description?.hasError) {
            runValidationTasks("description", value);
          }
          setDescription(value);
        }}
        onBlur={() => runValidationTasks("description", description)}
        errorMessage={errors.description?.errorMessage}
        hasError={errors.description?.hasError}
        {...getOverrideProps(overrides, "description")}
      ></TextField>
      <TextField
        label="Title"
        isRequired={false}
        isReadOnly={false}
        value={title}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title: value,
              organizationID,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.title ?? value;
          }
          if (errors.title?.hasError) {
            runValidationTasks("title", value);
          }
          setTitle(value);
        }}
        onBlur={() => runValidationTasks("title", title)}
        errorMessage={errors.title?.errorMessage}
        hasError={errors.title?.hasError}
        {...getOverrideProps(overrides, "title")}
      ></TextField>
      <TextField
        label="Organization id"
        isRequired={false}
        isReadOnly={false}
        value={organizationID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID: value,
              estimatedCost,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.organizationID ?? value;
          }
          if (errors.organizationID?.hasError) {
            runValidationTasks("organizationID", value);
          }
          setOrganizationID(value);
        }}
        onBlur={() => runValidationTasks("organizationID", organizationID)}
        errorMessage={errors.organizationID?.errorMessage}
        hasError={errors.organizationID?.hasError}
        {...getOverrideProps(overrides, "organizationID")}
      ></TextField>
      <TextField
        label="Estimated cost"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={estimatedCost}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost: value,
              finalCost,
              type,
            };
            const result = onChange(modelFields);
            value = result?.estimatedCost ?? value;
          }
          if (errors.estimatedCost?.hasError) {
            runValidationTasks("estimatedCost", value);
          }
          setEstimatedCost(value);
        }}
        onBlur={() => runValidationTasks("estimatedCost", estimatedCost)}
        errorMessage={errors.estimatedCost?.errorMessage}
        hasError={errors.estimatedCost?.hasError}
        {...getOverrideProps(overrides, "estimatedCost")}
      ></TextField>
      <TextField
        label="Final cost"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={finalCost}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost: value,
              type,
            };
            const result = onChange(modelFields);
            value = result?.finalCost ?? value;
          }
          if (errors.finalCost?.hasError) {
            runValidationTasks("finalCost", value);
          }
          setFinalCost(value);
        }}
        onBlur={() => runValidationTasks("finalCost", finalCost)}
        errorMessage={errors.finalCost?.errorMessage}
        hasError={errors.finalCost?.hasError}
        {...getOverrideProps(overrides, "finalCost")}
      ></TextField>
      <TextField
        label="Type"
        isRequired={false}
        isReadOnly={false}
        value={type}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              creatorID,
              creatorName,
              handlerID,
              handlerName,
              watcherID,
              watcherName,
              tenantID,
              tenantName,
              contractor,
              entityID,
              entityType,
              dateCreated,
              dateUpdated,
              status,
              description,
              title,
              organizationID,
              estimatedCost,
              finalCost,
              type: value,
            };
            const result = onChange(modelFields);
            value = result?.type ?? value;
          }
          if (errors.type?.hasError) {
            runValidationTasks("type", value);
          }
          setType(value);
        }}
        onBlur={() => runValidationTasks("type", type)}
        errorMessage={errors.type?.errorMessage}
        hasError={errors.type?.hasError}
        {...getOverrideProps(overrides, "type")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Reset"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          isDisabled={!(idProp || serviceRequestModelProp)}
          {...getOverrideProps(overrides, "ResetButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={
              !(idProp || serviceRequestModelProp) ||
              Object.values(errors).some((e) => e?.hasError)
            }
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
