/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { createUserOrganizationConnection } from "../graphql/mutations";
export default function UserOrganizationConnectionCreateForm(props) {
  const {
    clearOnSuccess = true,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    userID: "",
    username: "",
    creatorID: "",
    creatorName: "",
    organizationID: "",
    managerID: "",
    managerName: "",
    title: "",
    salary: "",
    ownershipType: "",
    clearanceLevel: "",
    joinedDate: "",
  };
  const [userID, setUserID] = React.useState(initialValues.userID);
  const [username, setUsername] = React.useState(initialValues.username);
  const [creatorID, setCreatorID] = React.useState(initialValues.creatorID);
  const [creatorName, setCreatorName] = React.useState(
    initialValues.creatorName
  );
  const [organizationID, setOrganizationID] = React.useState(
    initialValues.organizationID
  );
  const [managerID, setManagerID] = React.useState(initialValues.managerID);
  const [managerName, setManagerName] = React.useState(
    initialValues.managerName
  );
  const [title, setTitle] = React.useState(initialValues.title);
  const [salary, setSalary] = React.useState(initialValues.salary);
  const [ownershipType, setOwnershipType] = React.useState(
    initialValues.ownershipType
  );
  const [clearanceLevel, setClearanceLevel] = React.useState(
    initialValues.clearanceLevel
  );
  const [joinedDate, setJoinedDate] = React.useState(initialValues.joinedDate);
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    setUserID(initialValues.userID);
    setUsername(initialValues.username);
    setCreatorID(initialValues.creatorID);
    setCreatorName(initialValues.creatorName);
    setOrganizationID(initialValues.organizationID);
    setManagerID(initialValues.managerID);
    setManagerName(initialValues.managerName);
    setTitle(initialValues.title);
    setSalary(initialValues.salary);
    setOwnershipType(initialValues.ownershipType);
    setClearanceLevel(initialValues.clearanceLevel);
    setJoinedDate(initialValues.joinedDate);
    setErrors({});
  };
  const validations = {
    userID: [],
    username: [],
    creatorID: [],
    creatorName: [],
    organizationID: [],
    managerID: [],
    managerName: [],
    title: [],
    salary: [],
    ownershipType: [],
    clearanceLevel: [],
    joinedDate: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          userID,
          username,
          creatorID,
          creatorName,
          organizationID,
          managerID,
          managerName,
          title,
          salary,
          ownershipType,
          clearanceLevel,
          joinedDate,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: createUserOrganizationConnection.replaceAll(
              "__typename",
              ""
            ),
            variables: {
              input: {
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
          if (clearOnSuccess) {
            resetStateValues();
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "UserOrganizationConnectionCreateForm")}
      {...rest}
    >
      <TextField
        label="User id"
        isRequired={false}
        isReadOnly={false}
        value={userID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID: value,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.userID ?? value;
          }
          if (errors.userID?.hasError) {
            runValidationTasks("userID", value);
          }
          setUserID(value);
        }}
        onBlur={() => runValidationTasks("userID", userID)}
        errorMessage={errors.userID?.errorMessage}
        hasError={errors.userID?.hasError}
        {...getOverrideProps(overrides, "userID")}
      ></TextField>
      <TextField
        label="Username"
        isRequired={false}
        isReadOnly={false}
        value={username}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username: value,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.username ?? value;
          }
          if (errors.username?.hasError) {
            runValidationTasks("username", value);
          }
          setUsername(value);
        }}
        onBlur={() => runValidationTasks("username", username)}
        errorMessage={errors.username?.errorMessage}
        hasError={errors.username?.hasError}
        {...getOverrideProps(overrides, "username")}
      ></TextField>
      <TextField
        label="Creator id"
        isRequired={false}
        isReadOnly={false}
        value={creatorID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID: value,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.creatorID ?? value;
          }
          if (errors.creatorID?.hasError) {
            runValidationTasks("creatorID", value);
          }
          setCreatorID(value);
        }}
        onBlur={() => runValidationTasks("creatorID", creatorID)}
        errorMessage={errors.creatorID?.errorMessage}
        hasError={errors.creatorID?.hasError}
        {...getOverrideProps(overrides, "creatorID")}
      ></TextField>
      <TextField
        label="Creator name"
        isRequired={false}
        isReadOnly={false}
        value={creatorName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName: value,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.creatorName ?? value;
          }
          if (errors.creatorName?.hasError) {
            runValidationTasks("creatorName", value);
          }
          setCreatorName(value);
        }}
        onBlur={() => runValidationTasks("creatorName", creatorName)}
        errorMessage={errors.creatorName?.errorMessage}
        hasError={errors.creatorName?.hasError}
        {...getOverrideProps(overrides, "creatorName")}
      ></TextField>
      <TextField
        label="Organization id"
        isRequired={false}
        isReadOnly={false}
        value={organizationID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID: value,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.organizationID ?? value;
          }
          if (errors.organizationID?.hasError) {
            runValidationTasks("organizationID", value);
          }
          setOrganizationID(value);
        }}
        onBlur={() => runValidationTasks("organizationID", organizationID)}
        errorMessage={errors.organizationID?.errorMessage}
        hasError={errors.organizationID?.hasError}
        {...getOverrideProps(overrides, "organizationID")}
      ></TextField>
      <TextField
        label="Manager id"
        isRequired={false}
        isReadOnly={false}
        value={managerID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID: value,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.managerID ?? value;
          }
          if (errors.managerID?.hasError) {
            runValidationTasks("managerID", value);
          }
          setManagerID(value);
        }}
        onBlur={() => runValidationTasks("managerID", managerID)}
        errorMessage={errors.managerID?.errorMessage}
        hasError={errors.managerID?.hasError}
        {...getOverrideProps(overrides, "managerID")}
      ></TextField>
      <TextField
        label="Manager name"
        isRequired={false}
        isReadOnly={false}
        value={managerName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName: value,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.managerName ?? value;
          }
          if (errors.managerName?.hasError) {
            runValidationTasks("managerName", value);
          }
          setManagerName(value);
        }}
        onBlur={() => runValidationTasks("managerName", managerName)}
        errorMessage={errors.managerName?.errorMessage}
        hasError={errors.managerName?.hasError}
        {...getOverrideProps(overrides, "managerName")}
      ></TextField>
      <TextField
        label="Title"
        isRequired={false}
        isReadOnly={false}
        value={title}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title: value,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.title ?? value;
          }
          if (errors.title?.hasError) {
            runValidationTasks("title", value);
          }
          setTitle(value);
        }}
        onBlur={() => runValidationTasks("title", title)}
        errorMessage={errors.title?.errorMessage}
        hasError={errors.title?.hasError}
        {...getOverrideProps(overrides, "title")}
      ></TextField>
      <TextField
        label="Salary"
        isRequired={false}
        isReadOnly={false}
        value={salary}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary: value,
              ownershipType,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.salary ?? value;
          }
          if (errors.salary?.hasError) {
            runValidationTasks("salary", value);
          }
          setSalary(value);
        }}
        onBlur={() => runValidationTasks("salary", salary)}
        errorMessage={errors.salary?.errorMessage}
        hasError={errors.salary?.hasError}
        {...getOverrideProps(overrides, "salary")}
      ></TextField>
      <TextField
        label="Ownership type"
        isRequired={false}
        isReadOnly={false}
        value={ownershipType}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType: value,
              clearanceLevel,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.ownershipType ?? value;
          }
          if (errors.ownershipType?.hasError) {
            runValidationTasks("ownershipType", value);
          }
          setOwnershipType(value);
        }}
        onBlur={() => runValidationTasks("ownershipType", ownershipType)}
        errorMessage={errors.ownershipType?.errorMessage}
        hasError={errors.ownershipType?.hasError}
        {...getOverrideProps(overrides, "ownershipType")}
      ></TextField>
      <TextField
        label="Clearance level"
        isRequired={false}
        isReadOnly={false}
        value={clearanceLevel}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel: value,
              joinedDate,
            };
            const result = onChange(modelFields);
            value = result?.clearanceLevel ?? value;
          }
          if (errors.clearanceLevel?.hasError) {
            runValidationTasks("clearanceLevel", value);
          }
          setClearanceLevel(value);
        }}
        onBlur={() => runValidationTasks("clearanceLevel", clearanceLevel)}
        errorMessage={errors.clearanceLevel?.errorMessage}
        hasError={errors.clearanceLevel?.hasError}
        {...getOverrideProps(overrides, "clearanceLevel")}
      ></TextField>
      <TextField
        label="Joined date"
        isRequired={false}
        isReadOnly={false}
        value={joinedDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              userID,
              username,
              creatorID,
              creatorName,
              organizationID,
              managerID,
              managerName,
              title,
              salary,
              ownershipType,
              clearanceLevel,
              joinedDate: value,
            };
            const result = onChange(modelFields);
            value = result?.joinedDate ?? value;
          }
          if (errors.joinedDate?.hasError) {
            runValidationTasks("joinedDate", value);
          }
          setJoinedDate(value);
        }}
        onBlur={() => runValidationTasks("joinedDate", joinedDate)}
        errorMessage={errors.joinedDate?.errorMessage}
        hasError={errors.joinedDate?.hasError}
        {...getOverrideProps(overrides, "joinedDate")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Clear"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          {...getOverrideProps(overrides, "ClearButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={Object.values(errors).some((e) => e?.hasError)}
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
