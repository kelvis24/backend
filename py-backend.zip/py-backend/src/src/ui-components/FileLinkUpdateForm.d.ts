/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type FileLinkUpdateFormInputValues = {
    entityType?: string;
    entityID?: string;
    type?: string;
    storageLink?: string;
    name?: string;
};
export declare type FileLinkUpdateFormValidationValues = {
    entityType?: ValidationFunction<string>;
    entityID?: ValidationFunction<string>;
    type?: ValidationFunction<string>;
    storageLink?: ValidationFunction<string>;
    name?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type FileLinkUpdateFormOverridesProps = {
    FileLinkUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    type?: PrimitiveOverrideProps<TextFieldProps>;
    storageLink?: PrimitiveOverrideProps<TextFieldProps>;
    name?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type FileLinkUpdateFormProps = React.PropsWithChildren<{
    overrides?: FileLinkUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    fileLink?: any;
    onSubmit?: (fields: FileLinkUpdateFormInputValues) => FileLinkUpdateFormInputValues;
    onSuccess?: (fields: FileLinkUpdateFormInputValues) => void;
    onError?: (fields: FileLinkUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: FileLinkUpdateFormInputValues) => FileLinkUpdateFormInputValues;
    onValidate?: FileLinkUpdateFormValidationValues;
} & React.CSSProperties>;
export default function FileLinkUpdateForm(props: FileLinkUpdateFormProps): React.ReactElement;
