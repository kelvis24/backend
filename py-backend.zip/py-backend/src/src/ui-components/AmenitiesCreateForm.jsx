/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import {
  Button,
  Flex,
  Grid,
  SwitchField,
  TextField,
} from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { createAmenities } from "../graphql/mutations";
export default function AmenitiesCreateForm(props) {
  const {
    clearOnSuccess = true,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    entityID: "",
    entityType: "",
    name: "",
    areaSize: "",
    type: "",
    open: false,
    charge: "",
    availabilityDate: "",
  };
  const [entityID, setEntityID] = React.useState(initialValues.entityID);
  const [entityType, setEntityType] = React.useState(initialValues.entityType);
  const [name, setName] = React.useState(initialValues.name);
  const [areaSize, setAreaSize] = React.useState(initialValues.areaSize);
  const [type, setType] = React.useState(initialValues.type);
  const [open, setOpen] = React.useState(initialValues.open);
  const [charge, setCharge] = React.useState(initialValues.charge);
  const [availabilityDate, setAvailabilityDate] = React.useState(
    initialValues.availabilityDate
  );
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    setEntityID(initialValues.entityID);
    setEntityType(initialValues.entityType);
    setName(initialValues.name);
    setAreaSize(initialValues.areaSize);
    setType(initialValues.type);
    setOpen(initialValues.open);
    setCharge(initialValues.charge);
    setAvailabilityDate(initialValues.availabilityDate);
    setErrors({});
  };
  const validations = {
    entityID: [],
    entityType: [],
    name: [],
    areaSize: [],
    type: [],
    open: [],
    charge: [],
    availabilityDate: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          entityID,
          entityType,
          name,
          areaSize,
          type,
          open,
          charge,
          availabilityDate,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: createAmenities.replaceAll("__typename", ""),
            variables: {
              input: {
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
          if (clearOnSuccess) {
            resetStateValues();
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "AmenitiesCreateForm")}
      {...rest}
    >
      <TextField
        label="Entity id"
        isRequired={false}
        isReadOnly={false}
        value={entityID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              entityID: value,
              entityType,
              name,
              areaSize,
              type,
              open,
              charge,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.entityID ?? value;
          }
          if (errors.entityID?.hasError) {
            runValidationTasks("entityID", value);
          }
          setEntityID(value);
        }}
        onBlur={() => runValidationTasks("entityID", entityID)}
        errorMessage={errors.entityID?.errorMessage}
        hasError={errors.entityID?.hasError}
        {...getOverrideProps(overrides, "entityID")}
      ></TextField>
      <TextField
        label="Entity type"
        isRequired={false}
        isReadOnly={false}
        value={entityType}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              entityID,
              entityType: value,
              name,
              areaSize,
              type,
              open,
              charge,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.entityType ?? value;
          }
          if (errors.entityType?.hasError) {
            runValidationTasks("entityType", value);
          }
          setEntityType(value);
        }}
        onBlur={() => runValidationTasks("entityType", entityType)}
        errorMessage={errors.entityType?.errorMessage}
        hasError={errors.entityType?.hasError}
        {...getOverrideProps(overrides, "entityType")}
      ></TextField>
      <TextField
        label="Name"
        isRequired={false}
        isReadOnly={false}
        value={name}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              entityID,
              entityType,
              name: value,
              areaSize,
              type,
              open,
              charge,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.name ?? value;
          }
          if (errors.name?.hasError) {
            runValidationTasks("name", value);
          }
          setName(value);
        }}
        onBlur={() => runValidationTasks("name", name)}
        errorMessage={errors.name?.errorMessage}
        hasError={errors.name?.hasError}
        {...getOverrideProps(overrides, "name")}
      ></TextField>
      <TextField
        label="Area size"
        isRequired={false}
        isReadOnly={false}
        value={areaSize}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              entityID,
              entityType,
              name,
              areaSize: value,
              type,
              open,
              charge,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.areaSize ?? value;
          }
          if (errors.areaSize?.hasError) {
            runValidationTasks("areaSize", value);
          }
          setAreaSize(value);
        }}
        onBlur={() => runValidationTasks("areaSize", areaSize)}
        errorMessage={errors.areaSize?.errorMessage}
        hasError={errors.areaSize?.hasError}
        {...getOverrideProps(overrides, "areaSize")}
      ></TextField>
      <TextField
        label="Type"
        isRequired={false}
        isReadOnly={false}
        value={type}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              entityID,
              entityType,
              name,
              areaSize,
              type: value,
              open,
              charge,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.type ?? value;
          }
          if (errors.type?.hasError) {
            runValidationTasks("type", value);
          }
          setType(value);
        }}
        onBlur={() => runValidationTasks("type", type)}
        errorMessage={errors.type?.errorMessage}
        hasError={errors.type?.hasError}
        {...getOverrideProps(overrides, "type")}
      ></TextField>
      <SwitchField
        label="Open"
        defaultChecked={false}
        isDisabled={false}
        isChecked={open}
        onChange={(e) => {
          let value = e.target.checked;
          if (onChange) {
            const modelFields = {
              entityID,
              entityType,
              name,
              areaSize,
              type,
              open: value,
              charge,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.open ?? value;
          }
          if (errors.open?.hasError) {
            runValidationTasks("open", value);
          }
          setOpen(value);
        }}
        onBlur={() => runValidationTasks("open", open)}
        errorMessage={errors.open?.errorMessage}
        hasError={errors.open?.hasError}
        {...getOverrideProps(overrides, "open")}
      ></SwitchField>
      <TextField
        label="Charge"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={charge}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              entityID,
              entityType,
              name,
              areaSize,
              type,
              open,
              charge: value,
              availabilityDate,
            };
            const result = onChange(modelFields);
            value = result?.charge ?? value;
          }
          if (errors.charge?.hasError) {
            runValidationTasks("charge", value);
          }
          setCharge(value);
        }}
        onBlur={() => runValidationTasks("charge", charge)}
        errorMessage={errors.charge?.errorMessage}
        hasError={errors.charge?.hasError}
        {...getOverrideProps(overrides, "charge")}
      ></TextField>
      <TextField
        label="Availability date"
        isRequired={false}
        isReadOnly={false}
        value={availabilityDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              entityID,
              entityType,
              name,
              areaSize,
              type,
              open,
              charge,
              availabilityDate: value,
            };
            const result = onChange(modelFields);
            value = result?.availabilityDate ?? value;
          }
          if (errors.availabilityDate?.hasError) {
            runValidationTasks("availabilityDate", value);
          }
          setAvailabilityDate(value);
        }}
        onBlur={() => runValidationTasks("availabilityDate", availabilityDate)}
        errorMessage={errors.availabilityDate?.errorMessage}
        hasError={errors.availabilityDate?.hasError}
        {...getOverrideProps(overrides, "availabilityDate")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Clear"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          {...getOverrideProps(overrides, "ClearButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={Object.values(errors).some((e) => e?.hasError)}
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
