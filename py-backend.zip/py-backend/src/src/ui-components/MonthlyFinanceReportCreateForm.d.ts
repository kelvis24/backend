/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type MonthlyFinanceReportCreateFormInputValues = {
    yearlyReportId?: string;
    entityID?: string;
    entityType?: string;
    rentRevenue?: number;
    feesRevenue?: number;
    otherRevenue?: number;
    totalRevenue?: number;
    repairsExpenses?: number;
    lostRentExpenses?: number;
    renovationExpenses?: number;
    otherExpenses?: number;
    totalExpenses?: number;
    status?: string;
    net?: number;
    tenant?: string;
    actualRentPaymentDate?: string;
    numOccupied?: number;
    numVacant?: number;
    numRenovation?: number;
    month?: string;
    year?: string;
};
export declare type MonthlyFinanceReportCreateFormValidationValues = {
    yearlyReportId?: ValidationFunction<string>;
    entityID?: ValidationFunction<string>;
    entityType?: ValidationFunction<string>;
    rentRevenue?: ValidationFunction<number>;
    feesRevenue?: ValidationFunction<number>;
    otherRevenue?: ValidationFunction<number>;
    totalRevenue?: ValidationFunction<number>;
    repairsExpenses?: ValidationFunction<number>;
    lostRentExpenses?: ValidationFunction<number>;
    renovationExpenses?: ValidationFunction<number>;
    otherExpenses?: ValidationFunction<number>;
    totalExpenses?: ValidationFunction<number>;
    status?: ValidationFunction<string>;
    net?: ValidationFunction<number>;
    tenant?: ValidationFunction<string>;
    actualRentPaymentDate?: ValidationFunction<string>;
    numOccupied?: ValidationFunction<number>;
    numVacant?: ValidationFunction<number>;
    numRenovation?: ValidationFunction<number>;
    month?: ValidationFunction<string>;
    year?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type MonthlyFinanceReportCreateFormOverridesProps = {
    MonthlyFinanceReportCreateFormGrid?: PrimitiveOverrideProps<GridProps>;
    yearlyReportId?: PrimitiveOverrideProps<TextFieldProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    rentRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    feesRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    otherRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    totalRevenue?: PrimitiveOverrideProps<TextFieldProps>;
    repairsExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    lostRentExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    renovationExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    otherExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    totalExpenses?: PrimitiveOverrideProps<TextFieldProps>;
    status?: PrimitiveOverrideProps<TextFieldProps>;
    net?: PrimitiveOverrideProps<TextFieldProps>;
    tenant?: PrimitiveOverrideProps<TextFieldProps>;
    actualRentPaymentDate?: PrimitiveOverrideProps<TextFieldProps>;
    numOccupied?: PrimitiveOverrideProps<TextFieldProps>;
    numVacant?: PrimitiveOverrideProps<TextFieldProps>;
    numRenovation?: PrimitiveOverrideProps<TextFieldProps>;
    month?: PrimitiveOverrideProps<TextFieldProps>;
    year?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type MonthlyFinanceReportCreateFormProps = React.PropsWithChildren<{
    overrides?: MonthlyFinanceReportCreateFormOverridesProps | undefined | null;
} & {
    clearOnSuccess?: boolean;
    onSubmit?: (fields: MonthlyFinanceReportCreateFormInputValues) => MonthlyFinanceReportCreateFormInputValues;
    onSuccess?: (fields: MonthlyFinanceReportCreateFormInputValues) => void;
    onError?: (fields: MonthlyFinanceReportCreateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: MonthlyFinanceReportCreateFormInputValues) => MonthlyFinanceReportCreateFormInputValues;
    onValidate?: MonthlyFinanceReportCreateFormValidationValues;
} & React.CSSProperties>;
export default function MonthlyFinanceReportCreateForm(props: MonthlyFinanceReportCreateFormProps): React.ReactElement;
