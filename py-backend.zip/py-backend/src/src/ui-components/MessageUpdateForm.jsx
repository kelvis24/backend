/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { getMessage } from "../graphql/queries";
import { updateMessage } from "../graphql/mutations";
export default function MessageUpdateForm(props) {
  const {
    id: idProp,
    message: messageModelProp,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    title: "",
    content: "",
    senderID: "",
    senderName: "",
    receiverID: "",
    receiverName: "",
    type: "",
  };
  const [title, setTitle] = React.useState(initialValues.title);
  const [content, setContent] = React.useState(initialValues.content);
  const [senderID, setSenderID] = React.useState(initialValues.senderID);
  const [senderName, setSenderName] = React.useState(initialValues.senderName);
  const [receiverID, setReceiverID] = React.useState(initialValues.receiverID);
  const [receiverName, setReceiverName] = React.useState(
    initialValues.receiverName
  );
  const [type, setType] = React.useState(initialValues.type);
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    const cleanValues = messageRecord
      ? { ...initialValues, ...messageRecord }
      : initialValues;
    setTitle(cleanValues.title);
    setContent(cleanValues.content);
    setSenderID(cleanValues.senderID);
    setSenderName(cleanValues.senderName);
    setReceiverID(cleanValues.receiverID);
    setReceiverName(cleanValues.receiverName);
    setType(cleanValues.type);
    setErrors({});
  };
  const [messageRecord, setMessageRecord] = React.useState(messageModelProp);
  React.useEffect(() => {
    const queryData = async () => {
      const record = idProp
        ? (
            await API.graphql({
              query: getMessage.replaceAll("__typename", ""),
              variables: { id: idProp },
            })
          )?.data?.getMessage
        : messageModelProp;
      setMessageRecord(record);
    };
    queryData();
  }, [idProp, messageModelProp]);
  React.useEffect(resetStateValues, [messageRecord]);
  const validations = {
    title: [],
    content: [],
    senderID: [],
    senderName: [],
    receiverID: [],
    receiverName: [],
    type: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          title: title ?? null,
          content: content ?? null,
          senderID: senderID ?? null,
          senderName: senderName ?? null,
          receiverID: receiverID ?? null,
          receiverName: receiverName ?? null,
          type: type ?? null,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: updateMessage.replaceAll("__typename", ""),
            variables: {
              input: {
                id: messageRecord.id,
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "MessageUpdateForm")}
      {...rest}
    >
      <TextField
        label="Title"
        isRequired={false}
        isReadOnly={false}
        value={title}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title: value,
              content,
              senderID,
              senderName,
              receiverID,
              receiverName,
              type,
            };
            const result = onChange(modelFields);
            value = result?.title ?? value;
          }
          if (errors.title?.hasError) {
            runValidationTasks("title", value);
          }
          setTitle(value);
        }}
        onBlur={() => runValidationTasks("title", title)}
        errorMessage={errors.title?.errorMessage}
        hasError={errors.title?.hasError}
        {...getOverrideProps(overrides, "title")}
      ></TextField>
      <TextField
        label="Content"
        isRequired={false}
        isReadOnly={false}
        value={content}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title,
              content: value,
              senderID,
              senderName,
              receiverID,
              receiverName,
              type,
            };
            const result = onChange(modelFields);
            value = result?.content ?? value;
          }
          if (errors.content?.hasError) {
            runValidationTasks("content", value);
          }
          setContent(value);
        }}
        onBlur={() => runValidationTasks("content", content)}
        errorMessage={errors.content?.errorMessage}
        hasError={errors.content?.hasError}
        {...getOverrideProps(overrides, "content")}
      ></TextField>
      <TextField
        label="Sender id"
        isRequired={false}
        isReadOnly={false}
        value={senderID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title,
              content,
              senderID: value,
              senderName,
              receiverID,
              receiverName,
              type,
            };
            const result = onChange(modelFields);
            value = result?.senderID ?? value;
          }
          if (errors.senderID?.hasError) {
            runValidationTasks("senderID", value);
          }
          setSenderID(value);
        }}
        onBlur={() => runValidationTasks("senderID", senderID)}
        errorMessage={errors.senderID?.errorMessage}
        hasError={errors.senderID?.hasError}
        {...getOverrideProps(overrides, "senderID")}
      ></TextField>
      <TextField
        label="Sender name"
        isRequired={false}
        isReadOnly={false}
        value={senderName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title,
              content,
              senderID,
              senderName: value,
              receiverID,
              receiverName,
              type,
            };
            const result = onChange(modelFields);
            value = result?.senderName ?? value;
          }
          if (errors.senderName?.hasError) {
            runValidationTasks("senderName", value);
          }
          setSenderName(value);
        }}
        onBlur={() => runValidationTasks("senderName", senderName)}
        errorMessage={errors.senderName?.errorMessage}
        hasError={errors.senderName?.hasError}
        {...getOverrideProps(overrides, "senderName")}
      ></TextField>
      <TextField
        label="Receiver id"
        isRequired={false}
        isReadOnly={false}
        value={receiverID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title,
              content,
              senderID,
              senderName,
              receiverID: value,
              receiverName,
              type,
            };
            const result = onChange(modelFields);
            value = result?.receiverID ?? value;
          }
          if (errors.receiverID?.hasError) {
            runValidationTasks("receiverID", value);
          }
          setReceiverID(value);
        }}
        onBlur={() => runValidationTasks("receiverID", receiverID)}
        errorMessage={errors.receiverID?.errorMessage}
        hasError={errors.receiverID?.hasError}
        {...getOverrideProps(overrides, "receiverID")}
      ></TextField>
      <TextField
        label="Receiver name"
        isRequired={false}
        isReadOnly={false}
        value={receiverName}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title,
              content,
              senderID,
              senderName,
              receiverID,
              receiverName: value,
              type,
            };
            const result = onChange(modelFields);
            value = result?.receiverName ?? value;
          }
          if (errors.receiverName?.hasError) {
            runValidationTasks("receiverName", value);
          }
          setReceiverName(value);
        }}
        onBlur={() => runValidationTasks("receiverName", receiverName)}
        errorMessage={errors.receiverName?.errorMessage}
        hasError={errors.receiverName?.hasError}
        {...getOverrideProps(overrides, "receiverName")}
      ></TextField>
      <TextField
        label="Type"
        isRequired={false}
        isReadOnly={false}
        value={type}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              title,
              content,
              senderID,
              senderName,
              receiverID,
              receiverName,
              type: value,
            };
            const result = onChange(modelFields);
            value = result?.type ?? value;
          }
          if (errors.type?.hasError) {
            runValidationTasks("type", value);
          }
          setType(value);
        }}
        onBlur={() => runValidationTasks("type", type)}
        errorMessage={errors.type?.errorMessage}
        hasError={errors.type?.hasError}
        {...getOverrideProps(overrides, "type")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Reset"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          isDisabled={!(idProp || messageModelProp)}
          {...getOverrideProps(overrides, "ResetButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={
              !(idProp || messageModelProp) ||
              Object.values(errors).some((e) => e?.hasError)
            }
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
