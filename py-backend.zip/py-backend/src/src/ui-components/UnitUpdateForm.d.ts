/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type UnitUpdateFormInputValues = {
    status?: string;
    description?: string;
    name?: string;
    rent?: number;
    price?: string;
    numBedroom?: string;
    numBathroom?: string;
    availabilityDate?: string;
    expectedRentPaymentDate?: string;
    type?: string;
    size?: string;
    street?: string;
    buildingID?: string;
    tenantID?: string;
    contact?: string;
    userID?: string;
    organizationID?: string;
};
export declare type UnitUpdateFormValidationValues = {
    status?: ValidationFunction<string>;
    description?: ValidationFunction<string>;
    name?: ValidationFunction<string>;
    rent?: ValidationFunction<number>;
    price?: ValidationFunction<string>;
    numBedroom?: ValidationFunction<string>;
    numBathroom?: ValidationFunction<string>;
    availabilityDate?: ValidationFunction<string>;
    expectedRentPaymentDate?: ValidationFunction<string>;
    type?: ValidationFunction<string>;
    size?: ValidationFunction<string>;
    street?: ValidationFunction<string>;
    buildingID?: ValidationFunction<string>;
    tenantID?: ValidationFunction<string>;
    contact?: ValidationFunction<string>;
    userID?: ValidationFunction<string>;
    organizationID?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type UnitUpdateFormOverridesProps = {
    UnitUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    status?: PrimitiveOverrideProps<TextFieldProps>;
    description?: PrimitiveOverrideProps<TextFieldProps>;
    name?: PrimitiveOverrideProps<TextFieldProps>;
    rent?: PrimitiveOverrideProps<TextFieldProps>;
    price?: PrimitiveOverrideProps<TextFieldProps>;
    numBedroom?: PrimitiveOverrideProps<TextFieldProps>;
    numBathroom?: PrimitiveOverrideProps<TextFieldProps>;
    availabilityDate?: PrimitiveOverrideProps<TextFieldProps>;
    expectedRentPaymentDate?: PrimitiveOverrideProps<TextFieldProps>;
    type?: PrimitiveOverrideProps<TextFieldProps>;
    size?: PrimitiveOverrideProps<TextFieldProps>;
    street?: PrimitiveOverrideProps<TextFieldProps>;
    buildingID?: PrimitiveOverrideProps<TextFieldProps>;
    tenantID?: PrimitiveOverrideProps<TextFieldProps>;
    contact?: PrimitiveOverrideProps<TextFieldProps>;
    userID?: PrimitiveOverrideProps<TextFieldProps>;
    organizationID?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type UnitUpdateFormProps = React.PropsWithChildren<{
    overrides?: UnitUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    unit?: any;
    onSubmit?: (fields: UnitUpdateFormInputValues) => UnitUpdateFormInputValues;
    onSuccess?: (fields: UnitUpdateFormInputValues) => void;
    onError?: (fields: UnitUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: UnitUpdateFormInputValues) => UnitUpdateFormInputValues;
    onValidate?: UnitUpdateFormValidationValues;
} & React.CSSProperties>;
export default function UnitUpdateForm(props: UnitUpdateFormProps): React.ReactElement;
