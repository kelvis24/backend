/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type ServiceRequestUpdateFormInputValues = {
    creatorID?: string;
    creatorName?: string;
    handlerID?: string;
    handlerName?: string;
    watcherID?: string;
    watcherName?: string;
    tenantID?: string;
    tenantName?: string;
    contractor?: string;
    entityID?: string;
    entityType?: string;
    dateCreated?: string;
    dateUpdated?: string;
    status?: string;
    description?: string;
    title?: string;
    organizationID?: string;
    estimatedCost?: number;
    finalCost?: number;
    type?: string;
};
export declare type ServiceRequestUpdateFormValidationValues = {
    creatorID?: ValidationFunction<string>;
    creatorName?: ValidationFunction<string>;
    handlerID?: ValidationFunction<string>;
    handlerName?: ValidationFunction<string>;
    watcherID?: ValidationFunction<string>;
    watcherName?: ValidationFunction<string>;
    tenantID?: ValidationFunction<string>;
    tenantName?: ValidationFunction<string>;
    contractor?: ValidationFunction<string>;
    entityID?: ValidationFunction<string>;
    entityType?: ValidationFunction<string>;
    dateCreated?: ValidationFunction<string>;
    dateUpdated?: ValidationFunction<string>;
    status?: ValidationFunction<string>;
    description?: ValidationFunction<string>;
    title?: ValidationFunction<string>;
    organizationID?: ValidationFunction<string>;
    estimatedCost?: ValidationFunction<number>;
    finalCost?: ValidationFunction<number>;
    type?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type ServiceRequestUpdateFormOverridesProps = {
    ServiceRequestUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    creatorID?: PrimitiveOverrideProps<TextFieldProps>;
    creatorName?: PrimitiveOverrideProps<TextFieldProps>;
    handlerID?: PrimitiveOverrideProps<TextFieldProps>;
    handlerName?: PrimitiveOverrideProps<TextFieldProps>;
    watcherID?: PrimitiveOverrideProps<TextFieldProps>;
    watcherName?: PrimitiveOverrideProps<TextFieldProps>;
    tenantID?: PrimitiveOverrideProps<TextFieldProps>;
    tenantName?: PrimitiveOverrideProps<TextFieldProps>;
    contractor?: PrimitiveOverrideProps<TextFieldProps>;
    entityID?: PrimitiveOverrideProps<TextFieldProps>;
    entityType?: PrimitiveOverrideProps<TextFieldProps>;
    dateCreated?: PrimitiveOverrideProps<TextFieldProps>;
    dateUpdated?: PrimitiveOverrideProps<TextFieldProps>;
    status?: PrimitiveOverrideProps<TextFieldProps>;
    description?: PrimitiveOverrideProps<TextFieldProps>;
    title?: PrimitiveOverrideProps<TextFieldProps>;
    organizationID?: PrimitiveOverrideProps<TextFieldProps>;
    estimatedCost?: PrimitiveOverrideProps<TextFieldProps>;
    finalCost?: PrimitiveOverrideProps<TextFieldProps>;
    type?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type ServiceRequestUpdateFormProps = React.PropsWithChildren<{
    overrides?: ServiceRequestUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    serviceRequest?: any;
    onSubmit?: (fields: ServiceRequestUpdateFormInputValues) => ServiceRequestUpdateFormInputValues;
    onSuccess?: (fields: ServiceRequestUpdateFormInputValues) => void;
    onError?: (fields: ServiceRequestUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: ServiceRequestUpdateFormInputValues) => ServiceRequestUpdateFormInputValues;
    onValidate?: ServiceRequestUpdateFormValidationValues;
} & React.CSSProperties>;
export default function ServiceRequestUpdateForm(props: ServiceRequestUpdateFormProps): React.ReactElement;
