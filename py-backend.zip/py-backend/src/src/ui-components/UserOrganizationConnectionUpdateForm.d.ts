/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
export declare type EscapeHatchProps = {
    [elementHierarchy: string]: Record<string, unknown>;
} | null;
export declare type VariantValues = {
    [key: string]: string;
};
export declare type Variant = {
    variantValues: VariantValues;
    overrides: EscapeHatchProps;
};
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type UserOrganizationConnectionUpdateFormInputValues = {
    userID?: string;
    username?: string;
    creatorID?: string;
    creatorName?: string;
    organizationID?: string;
    managerID?: string;
    managerName?: string;
    title?: string;
    salary?: string;
    ownershipType?: string;
    clearanceLevel?: string;
    joinedDate?: string;
};
export declare type UserOrganizationConnectionUpdateFormValidationValues = {
    userID?: ValidationFunction<string>;
    username?: ValidationFunction<string>;
    creatorID?: ValidationFunction<string>;
    creatorName?: ValidationFunction<string>;
    organizationID?: ValidationFunction<string>;
    managerID?: ValidationFunction<string>;
    managerName?: ValidationFunction<string>;
    title?: ValidationFunction<string>;
    salary?: ValidationFunction<string>;
    ownershipType?: ValidationFunction<string>;
    clearanceLevel?: ValidationFunction<string>;
    joinedDate?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type UserOrganizationConnectionUpdateFormOverridesProps = {
    UserOrganizationConnectionUpdateFormGrid?: PrimitiveOverrideProps<GridProps>;
    userID?: PrimitiveOverrideProps<TextFieldProps>;
    username?: PrimitiveOverrideProps<TextFieldProps>;
    creatorID?: PrimitiveOverrideProps<TextFieldProps>;
    creatorName?: PrimitiveOverrideProps<TextFieldProps>;
    organizationID?: PrimitiveOverrideProps<TextFieldProps>;
    managerID?: PrimitiveOverrideProps<TextFieldProps>;
    managerName?: PrimitiveOverrideProps<TextFieldProps>;
    title?: PrimitiveOverrideProps<TextFieldProps>;
    salary?: PrimitiveOverrideProps<TextFieldProps>;
    ownershipType?: PrimitiveOverrideProps<TextFieldProps>;
    clearanceLevel?: PrimitiveOverrideProps<TextFieldProps>;
    joinedDate?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type UserOrganizationConnectionUpdateFormProps = React.PropsWithChildren<{
    overrides?: UserOrganizationConnectionUpdateFormOverridesProps | undefined | null;
} & {
    id?: string;
    userOrganizationConnection?: any;
    onSubmit?: (fields: UserOrganizationConnectionUpdateFormInputValues) => UserOrganizationConnectionUpdateFormInputValues;
    onSuccess?: (fields: UserOrganizationConnectionUpdateFormInputValues) => void;
    onError?: (fields: UserOrganizationConnectionUpdateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: UserOrganizationConnectionUpdateFormInputValues) => UserOrganizationConnectionUpdateFormInputValues;
    onValidate?: UserOrganizationConnectionUpdateFormValidationValues;
} & React.CSSProperties>;
export default function UserOrganizationConnectionUpdateForm(props: UserOrganizationConnectionUpdateFormProps): React.ReactElement;
