/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { getBuilding } from "../graphql/queries";
import { updateBuilding } from "../graphql/mutations";
export default function BuildingUpdateForm(props) {
  const {
    id: idProp,
    building: buildingModelProp,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    status: "",
    description: "",
    name: "",
    rent: "",
    price: "",
    numBedroom: "",
    numBathroom: "",
    expectedRentPaymentDate: "",
    size: "",
    street: "",
    propertyID: "",
    type: "",
    contact: "",
    userID: "",
    organizationID: "",
  };
  const [status, setStatus] = React.useState(initialValues.status);
  const [description, setDescription] = React.useState(
    initialValues.description
  );
  const [name, setName] = React.useState(initialValues.name);
  const [rent, setRent] = React.useState(initialValues.rent);
  const [price, setPrice] = React.useState(initialValues.price);
  const [numBedroom, setNumBedroom] = React.useState(initialValues.numBedroom);
  const [numBathroom, setNumBathroom] = React.useState(
    initialValues.numBathroom
  );
  const [expectedRentPaymentDate, setExpectedRentPaymentDate] = React.useState(
    initialValues.expectedRentPaymentDate
  );
  const [size, setSize] = React.useState(initialValues.size);
  const [street, setStreet] = React.useState(initialValues.street);
  const [propertyID, setPropertyID] = React.useState(initialValues.propertyID);
  const [type, setType] = React.useState(initialValues.type);
  const [contact, setContact] = React.useState(initialValues.contact);
  const [userID, setUserID] = React.useState(initialValues.userID);
  const [organizationID, setOrganizationID] = React.useState(
    initialValues.organizationID
  );
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    const cleanValues = buildingRecord
      ? { ...initialValues, ...buildingRecord }
      : initialValues;
    setStatus(cleanValues.status);
    setDescription(cleanValues.description);
    setName(cleanValues.name);
    setRent(cleanValues.rent);
    setPrice(cleanValues.price);
    setNumBedroom(cleanValues.numBedroom);
    setNumBathroom(cleanValues.numBathroom);
    setExpectedRentPaymentDate(cleanValues.expectedRentPaymentDate);
    setSize(cleanValues.size);
    setStreet(cleanValues.street);
    setPropertyID(cleanValues.propertyID);
    setType(cleanValues.type);
    setContact(cleanValues.contact);
    setUserID(cleanValues.userID);
    setOrganizationID(cleanValues.organizationID);
    setErrors({});
  };
  const [buildingRecord, setBuildingRecord] = React.useState(buildingModelProp);
  React.useEffect(() => {
    const queryData = async () => {
      const record = idProp
        ? (
            await API.graphql({
              query: getBuilding.replaceAll("__typename", ""),
              variables: { id: idProp },
            })
          )?.data?.getBuilding
        : buildingModelProp;
      setBuildingRecord(record);
    };
    queryData();
  }, [idProp, buildingModelProp]);
  React.useEffect(resetStateValues, [buildingRecord]);
  const validations = {
    status: [],
    description: [],
    name: [],
    rent: [],
    price: [],
    numBedroom: [],
    numBathroom: [],
    expectedRentPaymentDate: [],
    size: [],
    street: [],
    propertyID: [],
    type: [],
    contact: [],
    userID: [],
    organizationID: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          status: status ?? null,
          description: description ?? null,
          name: name ?? null,
          rent: rent ?? null,
          price: price ?? null,
          numBedroom: numBedroom ?? null,
          numBathroom: numBathroom ?? null,
          expectedRentPaymentDate: expectedRentPaymentDate ?? null,
          size: size ?? null,
          street: street ?? null,
          propertyID: propertyID ?? null,
          type: type ?? null,
          contact: contact ?? null,
          userID: userID ?? null,
          organizationID: organizationID ?? null,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: updateBuilding.replaceAll("__typename", ""),
            variables: {
              input: {
                id: buildingRecord.id,
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "BuildingUpdateForm")}
      {...rest}
    >
      <TextField
        label="Status"
        isRequired={false}
        isReadOnly={false}
        value={status}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status: value,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.status ?? value;
          }
          if (errors.status?.hasError) {
            runValidationTasks("status", value);
          }
          setStatus(value);
        }}
        onBlur={() => runValidationTasks("status", status)}
        errorMessage={errors.status?.errorMessage}
        hasError={errors.status?.hasError}
        {...getOverrideProps(overrides, "status")}
      ></TextField>
      <TextField
        label="Description"
        isRequired={false}
        isReadOnly={false}
        value={description}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description: value,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.description ?? value;
          }
          if (errors.description?.hasError) {
            runValidationTasks("description", value);
          }
          setDescription(value);
        }}
        onBlur={() => runValidationTasks("description", description)}
        errorMessage={errors.description?.errorMessage}
        hasError={errors.description?.hasError}
        {...getOverrideProps(overrides, "description")}
      ></TextField>
      <TextField
        label="Name"
        isRequired={false}
        isReadOnly={false}
        value={name}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name: value,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.name ?? value;
          }
          if (errors.name?.hasError) {
            runValidationTasks("name", value);
          }
          setName(value);
        }}
        onBlur={() => runValidationTasks("name", name)}
        errorMessage={errors.name?.errorMessage}
        hasError={errors.name?.hasError}
        {...getOverrideProps(overrides, "name")}
      ></TextField>
      <TextField
        label="Rent"
        isRequired={false}
        isReadOnly={false}
        value={rent}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent: value,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.rent ?? value;
          }
          if (errors.rent?.hasError) {
            runValidationTasks("rent", value);
          }
          setRent(value);
        }}
        onBlur={() => runValidationTasks("rent", rent)}
        errorMessage={errors.rent?.errorMessage}
        hasError={errors.rent?.hasError}
        {...getOverrideProps(overrides, "rent")}
      ></TextField>
      <TextField
        label="Price"
        isRequired={false}
        isReadOnly={false}
        value={price}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price: value,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.price ?? value;
          }
          if (errors.price?.hasError) {
            runValidationTasks("price", value);
          }
          setPrice(value);
        }}
        onBlur={() => runValidationTasks("price", price)}
        errorMessage={errors.price?.errorMessage}
        hasError={errors.price?.hasError}
        {...getOverrideProps(overrides, "price")}
      ></TextField>
      <TextField
        label="Num bedroom"
        isRequired={false}
        isReadOnly={false}
        value={numBedroom}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom: value,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.numBedroom ?? value;
          }
          if (errors.numBedroom?.hasError) {
            runValidationTasks("numBedroom", value);
          }
          setNumBedroom(value);
        }}
        onBlur={() => runValidationTasks("numBedroom", numBedroom)}
        errorMessage={errors.numBedroom?.errorMessage}
        hasError={errors.numBedroom?.hasError}
        {...getOverrideProps(overrides, "numBedroom")}
      ></TextField>
      <TextField
        label="Num bathroom"
        isRequired={false}
        isReadOnly={false}
        value={numBathroom}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom: value,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.numBathroom ?? value;
          }
          if (errors.numBathroom?.hasError) {
            runValidationTasks("numBathroom", value);
          }
          setNumBathroom(value);
        }}
        onBlur={() => runValidationTasks("numBathroom", numBathroom)}
        errorMessage={errors.numBathroom?.errorMessage}
        hasError={errors.numBathroom?.hasError}
        {...getOverrideProps(overrides, "numBathroom")}
      ></TextField>
      <TextField
        label="Expected rent payment date"
        isRequired={false}
        isReadOnly={false}
        value={expectedRentPaymentDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate: value,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.expectedRentPaymentDate ?? value;
          }
          if (errors.expectedRentPaymentDate?.hasError) {
            runValidationTasks("expectedRentPaymentDate", value);
          }
          setExpectedRentPaymentDate(value);
        }}
        onBlur={() =>
          runValidationTasks("expectedRentPaymentDate", expectedRentPaymentDate)
        }
        errorMessage={errors.expectedRentPaymentDate?.errorMessage}
        hasError={errors.expectedRentPaymentDate?.hasError}
        {...getOverrideProps(overrides, "expectedRentPaymentDate")}
      ></TextField>
      <TextField
        label="Size"
        isRequired={false}
        isReadOnly={false}
        value={size}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size: value,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.size ?? value;
          }
          if (errors.size?.hasError) {
            runValidationTasks("size", value);
          }
          setSize(value);
        }}
        onBlur={() => runValidationTasks("size", size)}
        errorMessage={errors.size?.errorMessage}
        hasError={errors.size?.hasError}
        {...getOverrideProps(overrides, "size")}
      ></TextField>
      <TextField
        label="Street"
        isRequired={false}
        isReadOnly={false}
        value={street}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street: value,
              propertyID,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.street ?? value;
          }
          if (errors.street?.hasError) {
            runValidationTasks("street", value);
          }
          setStreet(value);
        }}
        onBlur={() => runValidationTasks("street", street)}
        errorMessage={errors.street?.errorMessage}
        hasError={errors.street?.hasError}
        {...getOverrideProps(overrides, "street")}
      ></TextField>
      <TextField
        label="Property id"
        isRequired={false}
        isReadOnly={false}
        value={propertyID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID: value,
              type,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.propertyID ?? value;
          }
          if (errors.propertyID?.hasError) {
            runValidationTasks("propertyID", value);
          }
          setPropertyID(value);
        }}
        onBlur={() => runValidationTasks("propertyID", propertyID)}
        errorMessage={errors.propertyID?.errorMessage}
        hasError={errors.propertyID?.hasError}
        {...getOverrideProps(overrides, "propertyID")}
      ></TextField>
      <TextField
        label="Type"
        isRequired={false}
        isReadOnly={false}
        value={type}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type: value,
              contact,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.type ?? value;
          }
          if (errors.type?.hasError) {
            runValidationTasks("type", value);
          }
          setType(value);
        }}
        onBlur={() => runValidationTasks("type", type)}
        errorMessage={errors.type?.errorMessage}
        hasError={errors.type?.hasError}
        {...getOverrideProps(overrides, "type")}
      ></TextField>
      <TextField
        label="Contact"
        isRequired={false}
        isReadOnly={false}
        value={contact}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact: value,
              userID,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.contact ?? value;
          }
          if (errors.contact?.hasError) {
            runValidationTasks("contact", value);
          }
          setContact(value);
        }}
        onBlur={() => runValidationTasks("contact", contact)}
        errorMessage={errors.contact?.errorMessage}
        hasError={errors.contact?.hasError}
        {...getOverrideProps(overrides, "contact")}
      ></TextField>
      <TextField
        label="User id"
        isRequired={false}
        isReadOnly={false}
        value={userID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID: value,
              organizationID,
            };
            const result = onChange(modelFields);
            value = result?.userID ?? value;
          }
          if (errors.userID?.hasError) {
            runValidationTasks("userID", value);
          }
          setUserID(value);
        }}
        onBlur={() => runValidationTasks("userID", userID)}
        errorMessage={errors.userID?.errorMessage}
        hasError={errors.userID?.hasError}
        {...getOverrideProps(overrides, "userID")}
      ></TextField>
      <TextField
        label="Organization id"
        isRequired={false}
        isReadOnly={false}
        value={organizationID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              status,
              description,
              name,
              rent,
              price,
              numBedroom,
              numBathroom,
              expectedRentPaymentDate,
              size,
              street,
              propertyID,
              type,
              contact,
              userID,
              organizationID: value,
            };
            const result = onChange(modelFields);
            value = result?.organizationID ?? value;
          }
          if (errors.organizationID?.hasError) {
            runValidationTasks("organizationID", value);
          }
          setOrganizationID(value);
        }}
        onBlur={() => runValidationTasks("organizationID", organizationID)}
        errorMessage={errors.organizationID?.errorMessage}
        hasError={errors.organizationID?.hasError}
        {...getOverrideProps(overrides, "organizationID")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Reset"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          isDisabled={!(idProp || buildingModelProp)}
          {...getOverrideProps(overrides, "ResetButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={
              !(idProp || buildingModelProp) ||
              Object.values(errors).some((e) => e?.hasError)
            }
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
