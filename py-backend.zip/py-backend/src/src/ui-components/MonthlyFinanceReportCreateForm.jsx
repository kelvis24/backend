/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { Button, Flex, Grid, TextField } from "@aws-amplify/ui-react";
import { fetchByPath, getOverrideProps, validateField } from "./utils";
import { API } from "aws-amplify";
import { createMonthlyFinanceReport } from "../graphql/mutations";
export default function MonthlyFinanceReportCreateForm(props) {
  const {
    clearOnSuccess = true,
    onSuccess,
    onError,
    onSubmit,
    onValidate,
    onChange,
    overrides,
    ...rest
  } = props;
  const initialValues = {
    yearlyReportId: "",
    entityID: "",
    entityType: "",
    rentRevenue: "",
    feesRevenue: "",
    otherRevenue: "",
    totalRevenue: "",
    repairsExpenses: "",
    lostRentExpenses: "",
    renovationExpenses: "",
    otherExpenses: "",
    totalExpenses: "",
    status: "",
    net: "",
    tenant: "",
    actualRentPaymentDate: "",
    numOccupied: "",
    numVacant: "",
    numRenovation: "",
    month: "",
    year: "",
  };
  const [yearlyReportId, setYearlyReportId] = React.useState(
    initialValues.yearlyReportId
  );
  const [entityID, setEntityID] = React.useState(initialValues.entityID);
  const [entityType, setEntityType] = React.useState(initialValues.entityType);
  const [rentRevenue, setRentRevenue] = React.useState(
    initialValues.rentRevenue
  );
  const [feesRevenue, setFeesRevenue] = React.useState(
    initialValues.feesRevenue
  );
  const [otherRevenue, setOtherRevenue] = React.useState(
    initialValues.otherRevenue
  );
  const [totalRevenue, setTotalRevenue] = React.useState(
    initialValues.totalRevenue
  );
  const [repairsExpenses, setRepairsExpenses] = React.useState(
    initialValues.repairsExpenses
  );
  const [lostRentExpenses, setLostRentExpenses] = React.useState(
    initialValues.lostRentExpenses
  );
  const [renovationExpenses, setRenovationExpenses] = React.useState(
    initialValues.renovationExpenses
  );
  const [otherExpenses, setOtherExpenses] = React.useState(
    initialValues.otherExpenses
  );
  const [totalExpenses, setTotalExpenses] = React.useState(
    initialValues.totalExpenses
  );
  const [status, setStatus] = React.useState(initialValues.status);
  const [net, setNet] = React.useState(initialValues.net);
  const [tenant, setTenant] = React.useState(initialValues.tenant);
  const [actualRentPaymentDate, setActualRentPaymentDate] = React.useState(
    initialValues.actualRentPaymentDate
  );
  const [numOccupied, setNumOccupied] = React.useState(
    initialValues.numOccupied
  );
  const [numVacant, setNumVacant] = React.useState(initialValues.numVacant);
  const [numRenovation, setNumRenovation] = React.useState(
    initialValues.numRenovation
  );
  const [month, setMonth] = React.useState(initialValues.month);
  const [year, setYear] = React.useState(initialValues.year);
  const [errors, setErrors] = React.useState({});
  const resetStateValues = () => {
    setYearlyReportId(initialValues.yearlyReportId);
    setEntityID(initialValues.entityID);
    setEntityType(initialValues.entityType);
    setRentRevenue(initialValues.rentRevenue);
    setFeesRevenue(initialValues.feesRevenue);
    setOtherRevenue(initialValues.otherRevenue);
    setTotalRevenue(initialValues.totalRevenue);
    setRepairsExpenses(initialValues.repairsExpenses);
    setLostRentExpenses(initialValues.lostRentExpenses);
    setRenovationExpenses(initialValues.renovationExpenses);
    setOtherExpenses(initialValues.otherExpenses);
    setTotalExpenses(initialValues.totalExpenses);
    setStatus(initialValues.status);
    setNet(initialValues.net);
    setTenant(initialValues.tenant);
    setActualRentPaymentDate(initialValues.actualRentPaymentDate);
    setNumOccupied(initialValues.numOccupied);
    setNumVacant(initialValues.numVacant);
    setNumRenovation(initialValues.numRenovation);
    setMonth(initialValues.month);
    setYear(initialValues.year);
    setErrors({});
  };
  const validations = {
    yearlyReportId: [],
    entityID: [],
    entityType: [],
    rentRevenue: [],
    feesRevenue: [],
    otherRevenue: [],
    totalRevenue: [],
    repairsExpenses: [],
    lostRentExpenses: [],
    renovationExpenses: [],
    otherExpenses: [],
    totalExpenses: [],
    status: [],
    net: [],
    tenant: [],
    actualRentPaymentDate: [],
    numOccupied: [],
    numVacant: [],
    numRenovation: [],
    month: [],
    year: [],
  };
  const runValidationTasks = async (
    fieldName,
    currentValue,
    getDisplayValue
  ) => {
    const value =
      currentValue && getDisplayValue
        ? getDisplayValue(currentValue)
        : currentValue;
    let validationResponse = validateField(value, validations[fieldName]);
    const customValidator = fetchByPath(onValidate, fieldName);
    if (customValidator) {
      validationResponse = await customValidator(value, validationResponse);
    }
    setErrors((errors) => ({ ...errors, [fieldName]: validationResponse }));
    return validationResponse;
  };
  return (
    <Grid
      as="form"
      rowGap="15px"
      columnGap="15px"
      padding="20px"
      onSubmit={async (event) => {
        event.preventDefault();
        let modelFields = {
          yearlyReportId,
          entityID,
          entityType,
          rentRevenue,
          feesRevenue,
          otherRevenue,
          totalRevenue,
          repairsExpenses,
          lostRentExpenses,
          renovationExpenses,
          otherExpenses,
          totalExpenses,
          status,
          net,
          tenant,
          actualRentPaymentDate,
          numOccupied,
          numVacant,
          numRenovation,
          month,
          year,
        };
        const validationResponses = await Promise.all(
          Object.keys(validations).reduce((promises, fieldName) => {
            if (Array.isArray(modelFields[fieldName])) {
              promises.push(
                ...modelFields[fieldName].map((item) =>
                  runValidationTasks(fieldName, item)
                )
              );
              return promises;
            }
            promises.push(
              runValidationTasks(fieldName, modelFields[fieldName])
            );
            return promises;
          }, [])
        );
        if (validationResponses.some((r) => r.hasError)) {
          return;
        }
        if (onSubmit) {
          modelFields = onSubmit(modelFields);
        }
        try {
          Object.entries(modelFields).forEach(([key, value]) => {
            if (typeof value === "string" && value === "") {
              modelFields[key] = null;
            }
          });
          await API.graphql({
            query: createMonthlyFinanceReport.replaceAll("__typename", ""),
            variables: {
              input: {
                ...modelFields,
              },
            },
          });
          if (onSuccess) {
            onSuccess(modelFields);
          }
          if (clearOnSuccess) {
            resetStateValues();
          }
        } catch (err) {
          if (onError) {
            const messages = err.errors.map((e) => e.message).join("\n");
            onError(modelFields, messages);
          }
        }
      }}
      {...getOverrideProps(overrides, "MonthlyFinanceReportCreateForm")}
      {...rest}
    >
      <TextField
        label="Yearly report id"
        isRequired={false}
        isReadOnly={false}
        value={yearlyReportId}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId: value,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.yearlyReportId ?? value;
          }
          if (errors.yearlyReportId?.hasError) {
            runValidationTasks("yearlyReportId", value);
          }
          setYearlyReportId(value);
        }}
        onBlur={() => runValidationTasks("yearlyReportId", yearlyReportId)}
        errorMessage={errors.yearlyReportId?.errorMessage}
        hasError={errors.yearlyReportId?.hasError}
        {...getOverrideProps(overrides, "yearlyReportId")}
      ></TextField>
      <TextField
        label="Entity id"
        isRequired={false}
        isReadOnly={false}
        value={entityID}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID: value,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.entityID ?? value;
          }
          if (errors.entityID?.hasError) {
            runValidationTasks("entityID", value);
          }
          setEntityID(value);
        }}
        onBlur={() => runValidationTasks("entityID", entityID)}
        errorMessage={errors.entityID?.errorMessage}
        hasError={errors.entityID?.hasError}
        {...getOverrideProps(overrides, "entityID")}
      ></TextField>
      <TextField
        label="Entity type"
        isRequired={false}
        isReadOnly={false}
        value={entityType}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType: value,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.entityType ?? value;
          }
          if (errors.entityType?.hasError) {
            runValidationTasks("entityType", value);
          }
          setEntityType(value);
        }}
        onBlur={() => runValidationTasks("entityType", entityType)}
        errorMessage={errors.entityType?.errorMessage}
        hasError={errors.entityType?.hasError}
        {...getOverrideProps(overrides, "entityType")}
      ></TextField>
      <TextField
        label="Rent revenue"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={rentRevenue}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue: value,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.rentRevenue ?? value;
          }
          if (errors.rentRevenue?.hasError) {
            runValidationTasks("rentRevenue", value);
          }
          setRentRevenue(value);
        }}
        onBlur={() => runValidationTasks("rentRevenue", rentRevenue)}
        errorMessage={errors.rentRevenue?.errorMessage}
        hasError={errors.rentRevenue?.hasError}
        {...getOverrideProps(overrides, "rentRevenue")}
      ></TextField>
      <TextField
        label="Fees revenue"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={feesRevenue}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue: value,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.feesRevenue ?? value;
          }
          if (errors.feesRevenue?.hasError) {
            runValidationTasks("feesRevenue", value);
          }
          setFeesRevenue(value);
        }}
        onBlur={() => runValidationTasks("feesRevenue", feesRevenue)}
        errorMessage={errors.feesRevenue?.errorMessage}
        hasError={errors.feesRevenue?.hasError}
        {...getOverrideProps(overrides, "feesRevenue")}
      ></TextField>
      <TextField
        label="Other revenue"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={otherRevenue}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue: value,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.otherRevenue ?? value;
          }
          if (errors.otherRevenue?.hasError) {
            runValidationTasks("otherRevenue", value);
          }
          setOtherRevenue(value);
        }}
        onBlur={() => runValidationTasks("otherRevenue", otherRevenue)}
        errorMessage={errors.otherRevenue?.errorMessage}
        hasError={errors.otherRevenue?.hasError}
        {...getOverrideProps(overrides, "otherRevenue")}
      ></TextField>
      <TextField
        label="Total revenue"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={totalRevenue}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue: value,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.totalRevenue ?? value;
          }
          if (errors.totalRevenue?.hasError) {
            runValidationTasks("totalRevenue", value);
          }
          setTotalRevenue(value);
        }}
        onBlur={() => runValidationTasks("totalRevenue", totalRevenue)}
        errorMessage={errors.totalRevenue?.errorMessage}
        hasError={errors.totalRevenue?.hasError}
        {...getOverrideProps(overrides, "totalRevenue")}
      ></TextField>
      <TextField
        label="Repairs expenses"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={repairsExpenses}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses: value,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.repairsExpenses ?? value;
          }
          if (errors.repairsExpenses?.hasError) {
            runValidationTasks("repairsExpenses", value);
          }
          setRepairsExpenses(value);
        }}
        onBlur={() => runValidationTasks("repairsExpenses", repairsExpenses)}
        errorMessage={errors.repairsExpenses?.errorMessage}
        hasError={errors.repairsExpenses?.hasError}
        {...getOverrideProps(overrides, "repairsExpenses")}
      ></TextField>
      <TextField
        label="Lost rent expenses"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={lostRentExpenses}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses: value,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.lostRentExpenses ?? value;
          }
          if (errors.lostRentExpenses?.hasError) {
            runValidationTasks("lostRentExpenses", value);
          }
          setLostRentExpenses(value);
        }}
        onBlur={() => runValidationTasks("lostRentExpenses", lostRentExpenses)}
        errorMessage={errors.lostRentExpenses?.errorMessage}
        hasError={errors.lostRentExpenses?.hasError}
        {...getOverrideProps(overrides, "lostRentExpenses")}
      ></TextField>
      <TextField
        label="Renovation expenses"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={renovationExpenses}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses: value,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.renovationExpenses ?? value;
          }
          if (errors.renovationExpenses?.hasError) {
            runValidationTasks("renovationExpenses", value);
          }
          setRenovationExpenses(value);
        }}
        onBlur={() =>
          runValidationTasks("renovationExpenses", renovationExpenses)
        }
        errorMessage={errors.renovationExpenses?.errorMessage}
        hasError={errors.renovationExpenses?.hasError}
        {...getOverrideProps(overrides, "renovationExpenses")}
      ></TextField>
      <TextField
        label="Other expenses"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={otherExpenses}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses: value,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.otherExpenses ?? value;
          }
          if (errors.otherExpenses?.hasError) {
            runValidationTasks("otherExpenses", value);
          }
          setOtherExpenses(value);
        }}
        onBlur={() => runValidationTasks("otherExpenses", otherExpenses)}
        errorMessage={errors.otherExpenses?.errorMessage}
        hasError={errors.otherExpenses?.hasError}
        {...getOverrideProps(overrides, "otherExpenses")}
      ></TextField>
      <TextField
        label="Total expenses"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={totalExpenses}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses: value,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.totalExpenses ?? value;
          }
          if (errors.totalExpenses?.hasError) {
            runValidationTasks("totalExpenses", value);
          }
          setTotalExpenses(value);
        }}
        onBlur={() => runValidationTasks("totalExpenses", totalExpenses)}
        errorMessage={errors.totalExpenses?.errorMessage}
        hasError={errors.totalExpenses?.hasError}
        {...getOverrideProps(overrides, "totalExpenses")}
      ></TextField>
      <TextField
        label="Status"
        isRequired={false}
        isReadOnly={false}
        value={status}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status: value,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.status ?? value;
          }
          if (errors.status?.hasError) {
            runValidationTasks("status", value);
          }
          setStatus(value);
        }}
        onBlur={() => runValidationTasks("status", status)}
        errorMessage={errors.status?.errorMessage}
        hasError={errors.status?.hasError}
        {...getOverrideProps(overrides, "status")}
      ></TextField>
      <TextField
        label="Net"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={net}
        onChange={(e) => {
          let value = isNaN(parseFloat(e.target.value))
            ? e.target.value
            : parseFloat(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net: value,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.net ?? value;
          }
          if (errors.net?.hasError) {
            runValidationTasks("net", value);
          }
          setNet(value);
        }}
        onBlur={() => runValidationTasks("net", net)}
        errorMessage={errors.net?.errorMessage}
        hasError={errors.net?.hasError}
        {...getOverrideProps(overrides, "net")}
      ></TextField>
      <TextField
        label="Tenant"
        isRequired={false}
        isReadOnly={false}
        value={tenant}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant: value,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.tenant ?? value;
          }
          if (errors.tenant?.hasError) {
            runValidationTasks("tenant", value);
          }
          setTenant(value);
        }}
        onBlur={() => runValidationTasks("tenant", tenant)}
        errorMessage={errors.tenant?.errorMessage}
        hasError={errors.tenant?.hasError}
        {...getOverrideProps(overrides, "tenant")}
      ></TextField>
      <TextField
        label="Actual rent payment date"
        isRequired={false}
        isReadOnly={false}
        value={actualRentPaymentDate}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate: value,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.actualRentPaymentDate ?? value;
          }
          if (errors.actualRentPaymentDate?.hasError) {
            runValidationTasks("actualRentPaymentDate", value);
          }
          setActualRentPaymentDate(value);
        }}
        onBlur={() =>
          runValidationTasks("actualRentPaymentDate", actualRentPaymentDate)
        }
        errorMessage={errors.actualRentPaymentDate?.errorMessage}
        hasError={errors.actualRentPaymentDate?.hasError}
        {...getOverrideProps(overrides, "actualRentPaymentDate")}
      ></TextField>
      <TextField
        label="Num occupied"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={numOccupied}
        onChange={(e) => {
          let value = isNaN(parseInt(e.target.value))
            ? e.target.value
            : parseInt(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied: value,
              numVacant,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.numOccupied ?? value;
          }
          if (errors.numOccupied?.hasError) {
            runValidationTasks("numOccupied", value);
          }
          setNumOccupied(value);
        }}
        onBlur={() => runValidationTasks("numOccupied", numOccupied)}
        errorMessage={errors.numOccupied?.errorMessage}
        hasError={errors.numOccupied?.hasError}
        {...getOverrideProps(overrides, "numOccupied")}
      ></TextField>
      <TextField
        label="Num vacant"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={numVacant}
        onChange={(e) => {
          let value = isNaN(parseInt(e.target.value))
            ? e.target.value
            : parseInt(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant: value,
              numRenovation,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.numVacant ?? value;
          }
          if (errors.numVacant?.hasError) {
            runValidationTasks("numVacant", value);
          }
          setNumVacant(value);
        }}
        onBlur={() => runValidationTasks("numVacant", numVacant)}
        errorMessage={errors.numVacant?.errorMessage}
        hasError={errors.numVacant?.hasError}
        {...getOverrideProps(overrides, "numVacant")}
      ></TextField>
      <TextField
        label="Num renovation"
        isRequired={false}
        isReadOnly={false}
        type="number"
        step="any"
        value={numRenovation}
        onChange={(e) => {
          let value = isNaN(parseInt(e.target.value))
            ? e.target.value
            : parseInt(e.target.value);
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation: value,
              month,
              year,
            };
            const result = onChange(modelFields);
            value = result?.numRenovation ?? value;
          }
          if (errors.numRenovation?.hasError) {
            runValidationTasks("numRenovation", value);
          }
          setNumRenovation(value);
        }}
        onBlur={() => runValidationTasks("numRenovation", numRenovation)}
        errorMessage={errors.numRenovation?.errorMessage}
        hasError={errors.numRenovation?.hasError}
        {...getOverrideProps(overrides, "numRenovation")}
      ></TextField>
      <TextField
        label="Month"
        isRequired={false}
        isReadOnly={false}
        value={month}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month: value,
              year,
            };
            const result = onChange(modelFields);
            value = result?.month ?? value;
          }
          if (errors.month?.hasError) {
            runValidationTasks("month", value);
          }
          setMonth(value);
        }}
        onBlur={() => runValidationTasks("month", month)}
        errorMessage={errors.month?.errorMessage}
        hasError={errors.month?.hasError}
        {...getOverrideProps(overrides, "month")}
      ></TextField>
      <TextField
        label="Year"
        isRequired={false}
        isReadOnly={false}
        value={year}
        onChange={(e) => {
          let { value } = e.target;
          if (onChange) {
            const modelFields = {
              yearlyReportId,
              entityID,
              entityType,
              rentRevenue,
              feesRevenue,
              otherRevenue,
              totalRevenue,
              repairsExpenses,
              lostRentExpenses,
              renovationExpenses,
              otherExpenses,
              totalExpenses,
              status,
              net,
              tenant,
              actualRentPaymentDate,
              numOccupied,
              numVacant,
              numRenovation,
              month,
              year: value,
            };
            const result = onChange(modelFields);
            value = result?.year ?? value;
          }
          if (errors.year?.hasError) {
            runValidationTasks("year", value);
          }
          setYear(value);
        }}
        onBlur={() => runValidationTasks("year", year)}
        errorMessage={errors.year?.errorMessage}
        hasError={errors.year?.hasError}
        {...getOverrideProps(overrides, "year")}
      ></TextField>
      <Flex
        justifyContent="space-between"
        {...getOverrideProps(overrides, "CTAFlex")}
      >
        <Button
          children="Clear"
          type="reset"
          onClick={(event) => {
            event.preventDefault();
            resetStateValues();
          }}
          {...getOverrideProps(overrides, "ClearButton")}
        ></Button>
        <Flex
          gap="15px"
          {...getOverrideProps(overrides, "RightAlignCTASubFlex")}
        >
          <Button
            children="Submit"
            type="submit"
            variation="primary"
            isDisabled={Object.values(errors).some((e) => e?.hasError)}
            {...getOverrideProps(overrides, "SubmitButton")}
          ></Button>
        </Flex>
      </Flex>
    </Grid>
  );
}
