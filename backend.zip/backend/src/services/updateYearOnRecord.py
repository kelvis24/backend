import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import *


# Boto Attr docs: https://boto3.amazonaws.com/v1/documentation/api/latest/guide/dynamodb.html#updating-an-item
def update_year_on_record(id, years, updatedAt):
    try:
        # Create a simple HTML page with an explanation of what Safety Scan does
        # Get the service resource.
        # Stackoverflow cred issues solution
        # https://stackoverflow.com/questions/33297172/boto3-error-botocore-exceptions-nocredentialserror-unable-to-locate-credential
        AWS_S3_CREDS = {
            "aws_access_key_id": "AKIA3HSN3MXEBW3FKWPY",  # os.getenv("AWS_ACCESS_KEY")
            "aws_secret_access_key": "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",  # os.getenv("AWS_SECRET_KEY")
        }
        dynamodb = boto3.resource("dynamodb", "us-east-2", **AWS_S3_CREDS)

        # Instantiate a table resource object without actually
        # creating a DynamoDB table. Note that the attributes of this table
        # are lazy-loaded: a request is not made nor are the attribute
        # values populated until the attributes
        # on the table resource are accessed or its load() method is called.
        table = dynamodb.Table("YearRecords-eyn6yvqoabdjnelzcyukkje5ga-main")
        putResponse = table.update_item(
            Key={
                "id": id,
            },
            UpdateExpression="SET years = :years1, updatedAt = :updated1",
            ExpressionAttributeValues={":years1": years, ":updated1": updatedAt},
        )
        return putResponse
    except Exception as exception:
        print(f"Error updating year on record: {exception}")
        return {}
