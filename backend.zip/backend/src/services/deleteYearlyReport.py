import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import *


# Boto delete items Attr docs: https://boto3.amazonaws.com/v1/documentation/api/latest/guide/dynamodb.html#deleting-an-item
def delete_yearly_report(id):
    try:
        # Create a simple HTML page with an explanation of what Safety Scan does
        # Get the service resource.
        # Stackoverflow cred issues solution
        # https://stackoverflow.com/questions/33297172/boto3-error-botocore-exceptions-nocredentialserror-unable-to-locate-credential
        AWS_S3_CREDS = {
            "aws_access_key_id": "AKIA3HSN3MXEBW3FKWPY",  # os.getenv("AWS_ACCESS_KEY")
            "aws_secret_access_key": "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",  # os.getenv("AWS_SECRET_KEY")
        }
        dynamodb = boto3.resource("dynamodb", "us-east-2", **AWS_S3_CREDS)

        # Instantiate a table resource object without actually
        # creating a DynamoDB table. Note that the attributes of this table
        # are lazy-loaded: a request is not made nor are the attribute
        # values populated until the attributes
        # on the table resource are accessed or its load() method is called.
        table = dynamodb.Table("YearlyReportSummary-eyn6yvqoabdjnelzcyukkje5ga-main")
        putResponse = table.delete_item(
            Key={
                "id": id,
            },
        )
        return putResponse
    except Exception as exception:
        print(f"Error deleting yearly report: {exception}")
        return {}
