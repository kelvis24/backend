from flask import Flask, jsonify, render_template, request
import firebase_admin
from firebase_admin import credentials, initialize_app, storage
from datetime import datetime
from flask_cors import CORS
import uuid
import json
import requests
from datetime import datetime
from decimal import *

# boto 3 setup docs: https://boto3.amazonaws.com/v1/documentation/api/latest/guide/quickstart.html
import boto3
from boto3.dynamodb.conditions import Key, Attr

from app.src.services.getPropertyList import get_property_list
from app.src.services.getPropertyDetails import get_property_details
from app.src.services.getBuildingList import get_building_list
from app.src.services.getUnitList import get_unit_list
from app.src.services.getServiceRequestList import get_service_request_list
from app.src.services.getMonthlyReportDetails import get_monthly_report_details
from app.src.services.addMonthlyReport import add_monthly_report
from app.src.services.getYearlyReportDetails import get_yearly_report_details
from app.src.services.addYearlyReportDetails import add_yearly_report
from app.src.services.deleteMonthlyReport import delete_monthly_report
from app.src.services.deleteYearlyReport import delete_yearly_report
from app.src.services.addYearOnRecord import add_year_on_record
from app.src.services.deleteYearOnRecord import delete_year_on_record
from app.src.services.updateYearOnRecord import update_year_on_record
from app.src.services.getYearOnRecord import get_year_on_record


# Get the service resource.
dynamodb = boto3.resource("dynamodb", "us-east-2")

# Instantiate a table resource object without actually
# creating a DynamoDB table. Note that the attributes of this table
# are lazy-loaded: a request is not made nor are the attribute
# values populated until the attributes
# on the table resource are accessed or its load() method is called.
table = dynamodb.Table("Property")

# Print out some data about the table.
# This will cause a request to be made to DynamoDB and its attribute
# values will be set based on the response.
# print(table)

app = Flask(__name__)
CORS(app)

project_id = "realestatemgmt-d3faa"
# Initialize Firebase Admin SDK with your credentials
cred = credentials.Certificate(
    "app/src/realestatemgmt-d3faa-firebase-adminsdk-hhsti-34f510350a.json"
)
firebase_admin.initialize_app(cred, {"storageBucket": f"{project_id}.appspot.com"})


@app.route("/")
def home():
    # Create a simple HTML page with an explanation of what Safety Scan does
    return render_template("/index.html")


@app.route("/organization")
def organization():
    # Create a simple HTML page with an explanation of what Safety Scan does
    return render_template("/organization.html")


@app.route("/api/v1/property")
def getProperty():
    # Create a simple HTML page with an explanation of what Safety Scan does
    # Get the service resource.
    AWS_S3_CREDS = {
        "aws_access_key_id": "AKIA3HSN3MXEBW3FKWPY",  # os.getenv("AWS_ACCESS_KEY")
        "aws_secret_access_key": "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",  # os.getenv("AWS_SECRET_KEY")
    }
    dynamodb = boto3.resource("dynamodb", "us-east-2", **AWS_S3_CREDS)

    # Instantiate a table resource object without actually
    # creating a DynamoDB table. Note that the attributes of this table
    # are lazy-loaded: a request is not made nor are the attribute
    # values populated until the attributes
    # on the table resource are accessed or its load() method is called.
    table = dynamodb.Table("Property-eyn6yvqoabdjnelzcyukkje5ga-main")
    response = table.get_item(Key={"id": "08840705-0027-43d4-8ea8-29b09535a58d"})
    # getAll = table.get_item(Key={"id": ""})
    queryResponse = table.scan(FilterExpression=Attr("id").ne("johndoe"))

    item = response["Item"]
    # print(queryResponse)
    return queryResponse["Items"]


@app.route(
    "/api/v1/finance/report/<currentYear>/<currentMonth>/<currentDay>/<entityType>/<entityID>/<close>"
)
def getYearlyFinanceReport(
    currentYear, currentMonth, currentDay, entityType, entityID, close
):
    shouldUpdate = False
    yearlyReport = get_yearly_report_details(entityType, entityID, currentYear)
    yearlyReportId = f"{currentYear}-{entityType}-{entityID}"
    if "status" in yearlyReport:
        shouldUpdate = True
        yearlyReportId = yearlyReport["id"]
        if yearlyReport["status"] == "Closed":
            return yearlyReport
    totalRent = Decimal(yearlyReport["confirmedRentRevenue"])
    totalFees = Decimal(yearlyReport["confirmedFeesRevenue"])
    totalOther = Decimal(yearlyReport["confirmedOtherRevenue"])
    totalLostRent = Decimal(yearlyReport["confirmedLostRentExpenses"])
    totalRenovation = Decimal(yearlyReport["confirmedRenovationExpenses"])
    totalRepairs = Decimal(yearlyReport["confirmedrepairsExpenses"])
    totalOtherExpenses = Decimal(yearlyReport["confirmedOtherExpenses"])

    propertyList = get_property_list(entityID) if entityType == "user" else []
    for i in range(0, len(propertyList)):
        property = propertyList[i]
        getYearlyFinanceReport(
            currentYear, currentMonth, currentDay, "property", property["id"], close
        )
    monthlyReport = (
        getMonthlyUserFianceReport(
            currentYear, currentMonth, currentDay, propertyList, entityID, close
        )
        if entityType == "user"
        else getMonthlyEntityFinanceReport(
            currentYear, currentMonth, currentDay, entityType, entityID, close
        )
    )
    numOccupied = monthlyReport.get("numOccupied", 0)
    numVacant = monthlyReport.get("numVacant", 0)
    numRenovation = monthlyReport.get("numRenovation", 0)
    totalRent = Decimal(yearlyReport["confirmedRentRevenue"]) + monthlyReport.get(
        "rentRevenue", Decimal(0)
    )
    totalFees = Decimal(yearlyReport["confirmedFeesRevenue"]) + monthlyReport.get(
        "feesRevenue", Decimal(0)
    )
    totalOther = Decimal(yearlyReport["confirmedOtherRevenue"]) + monthlyReport.get(
        "otherRevenue", Decimal(0)
    )
    totalLostRent = Decimal(
        yearlyReport["confirmedLostRentExpenses"]
    ) + monthlyReport.get("lostRentExpenses", Decimal(0))
    totalRenovation = Decimal(
        yearlyReport["confirmedRenovationExpenses"]
    ) + monthlyReport.get("renovationExpenses", Decimal(0))
    totalRepairs = Decimal(
        yearlyReport["confirmedrepairsExpenses"]
    ) + monthlyReport.get("repairsExpenses", Decimal(0))
    totalOtherExpenses = Decimal(
        yearlyReport["confirmedOtherExpenses"]
    ) + monthlyReport.get("otherExpenses", Decimal(0))
    totalRevenue = totalFees + totalRent + totalOther
    totalExpense = totalRepairs + totalLostRent + totalRenovation + totalOtherExpenses
    totalNet = totalRevenue - totalExpense
    date = datetime.now()
    reportPayload = {
        "id": yearlyReportId,
        "entityType": entityType,
        "entityID": entityID,
        "rentRevenue": totalRent,
        "feesRevenue": totalFees,
        "otherRevenue": totalOther,
        "totalRevenue": totalRevenue,
        "lostRentExpenses": totalLostRent,
        "repairsExpenses": totalRepairs,
        "renovationExpenses": totalRenovation,
        "otherExpenses": totalOtherExpenses,
        "totalExpenses": totalExpense,
        "status": "Closed" if close == "Closed" else "InProgress",
        "net": totalNet,
        "numOccupied": numOccupied,
        "numVacant": numVacant,
        "numRenovation": numRenovation,
        "year": currentYear,
        "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
        "createdAt": (
            datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z")
            if not shouldUpdate
            else monthlyReport["createdAt"]
        ),
        "confirmedRentRevenue": (
            totalRent if close == "Closed" else yearlyReport["confirmedRentRevenue"]
        ),
        "confirmedFeesRevenue": (
            totalFees if close == "Closed" else yearlyReport["confirmedFeesRevenue"]
        ),
        "confirmedOtherRevenue": (
            totalOther if close == "Closed" else yearlyReport["confirmedOtherRevenue"]
        ),
        "confirmedTotalRevenue": (
            totalRevenue if close == "Closed" else yearlyReport["confirmedTotalRevenue"]
        ),
        "confirmedLostRentExpenses": (
            totalLostRent
            if close == "Closed"
            else yearlyReport["confirmedLostRentExpenses"]
        ),
        "confirmedRenovationExpenses": (
            totalRenovation
            if close == "Closed"
            else yearlyReport["confirmedRenovationExpenses"]
        ),
        "confirmedrepairsExpenses": (
            totalRepairs
            if close == "Closed"
            else yearlyReport["confirmedrepairsExpenses"]
        ),
        "confirmedOtherExpenses": (
            totalOtherExpenses
            if close == "Closed"
            else yearlyReport["confirmedOtherExpenses"]
        ),
        "confirmedtotalExpenses": (
            totalExpense
            if close == "Closed"
            else yearlyReport["confirmedtotalExpenses"]
        ),
    }
    if shouldUpdate:
        deleteYearlyReport = delete_yearly_report(yearlyReportId)
        updatedYearlyReport = add_yearly_report(reportPayload)
    else:
        newYearlyReport = add_yearly_report(reportPayload)
        if entityType == "user":
            yearRecords = get_year_on_record(f"{entityID}-year-records")
            if "years" in yearRecords:
                newYears = yearRecords["years"]
                newYears.append(f"{currentYear}")
                update_year_on_record(
                    yearRecords["id"],
                    newYears,
                    datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
                )
            else:
                payload = {
                    "id": f"{entityID}-year-records",
                    "userID": entityID,
                    "years": [f"{currentYear}"],
                    "createdAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
                    "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
                }
                add_year_on_record(payload)
    return reportPayload


def getMonthlyUserFianceReport(
    currentYear, currentMonth, currentDay, propertyList, userID, close
):
    userMonthlyReport = get_monthly_report_details(
        entityType="user", entityID=userID, month=currentMonth, year=currentYear
    )
    shouldUpdate = False
    if "status" in userMonthlyReport:
        shouldUpdate = True
        if userMonthlyReport["status"] == "Closed":
            return userMonthlyReport
    totalRent = Decimal(0)
    totalFees = Decimal(0)
    totalOther = Decimal(0)
    totalLostRent = Decimal(0)
    totalRenovation = Decimal(0)
    totalRepairs = Decimal(0)
    totalOtherExpenses = Decimal(0)
    numOccupied = 0
    numVacant = 0
    numRenovation = 0
    for i in range(0, len(propertyList)):
        property = propertyList[i]
        monthlyReport = getMonthlyEntityFinanceReport(
            currentYear,
            currentMonth,
            currentDay,
            "property",
            property.get("id", ""),
            close,
        )
        numOccupied += monthlyReport.get("numOccupied", 0)
        numVacant += monthlyReport.get("numVacant", 0)
        numRenovation += monthlyReport.get("numRenovation", 0)
        totalRent += monthlyReport.get("rentRevenue", Decimal(0))
        totalFees += monthlyReport.get("feesRevenue", Decimal(0))
        totalOther += monthlyReport.get("otherRevenue", Decimal(0))
        totalLostRent += monthlyReport.get("lostRentExpenses", Decimal(0))
        totalRenovation += monthlyReport.get("renovationExpenses", Decimal(0))
        totalRepairs += monthlyReport.get("repairsExpenses", Decimal(0))
        totalOtherExpenses += monthlyReport.get("otherExpenses", Decimal(0))
    totalRevenue = totalFees + totalRent + totalOther
    totalExpense = totalRepairs + totalLostRent + totalRenovation + totalOtherExpenses
    totalNet = totalRevenue - totalExpense
    date = datetime.now()
    reportPayload = {
        "id": f"{currentYear}-{currentMonth}-user-{userID}",
        "yearlyReportId": f"{currentYear}-user-{userID}",
        "status": "Closed" if close == "Closed" else "InProgress",
        "entityType": "user",
        "entityID": userID,
        "rentRevenue": Decimal(totalRent),
        "feesRevenue": Decimal(totalFees),
        "otherRevenue": Decimal(totalOther),
        "totalRevenue": Decimal(totalRevenue),
        "lostRentExpenses": Decimal(totalLostRent),
        "repairsExpenses": Decimal(totalRepairs),
        "renovationExpenses": Decimal(totalRenovation),
        "otherExpenses": Decimal(totalOtherExpenses),
        "totalExpenses": Decimal(totalExpense),
        "net": Decimal(totalNet),
        "numOccupied": numOccupied,
        "numVacant": numVacant,
        "numRenovation": numRenovation,
        "month": currentMonth,
        "year": currentYear,
        "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
        "createdAt": (
            datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z")
            if not shouldUpdate
            else monthlyReport.get("createdAt", "")
        ),
    }
    if shouldUpdate:
        deleteMonthlyReport = delete_monthly_report(monthlyReport["id"])
        updatedMonthlyReport = add_monthly_report(reportPayload)
    else:
        newMonthlyReport = add_monthly_report(reportPayload)
    return reportPayload


def getMonthlyEntityFinanceReport(
    currentYear, currentMonth, currentDay, entityType, entityID, close
):
    monthlyReport = get_monthly_report_details(
        entityType=entityType, entityID=entityID, month=currentMonth, year=currentYear
    )
    shouldUpdate = False
    if "status" in monthlyReport:
        shouldUpdate = True
        if monthlyReport["status"] == "Closed":
            return monthlyReport
    totalRent = monthlyReport.get("rentRevenue", Decimal(0))
    totalFees = Decimal(0)
    totalOther = Decimal(0)
    totalOtherExpenses = Decimal(0)
    totalLostRent = Decimal(0)
    totalRenovation = Decimal(0)
    totalRepairs = Decimal(0)
    numOccupied = 0
    numVacant = 0
    numRenovation = 0
    if entityType == "property":
        # on the first of the month, create the report
        propertyExpenses = getTotalExpenses(
            "property", entityID, currentMonth, currentYear
        )
        totalFees += propertyExpenses["totalFees"]
        totalOther += propertyExpenses["totalOther"]
        totalRepairs += propertyExpenses["totalRepairs"]
        totalLostRent += propertyExpenses["totalLostRent"]
        totalRenovation += propertyExpenses["totalRenovation"]
        totalOtherExpenses += propertyExpenses["totalOtherExpenses"]
        buildingList = get_building_list("", propertyID=entityID)
        for i in range(0, len(buildingList)):
            building = buildingList[i]
            if building.get("type", "Single") == "Multiple":
                if building.get("status", "None") == "Occupied":
                    numOccupied += 1
                    totalRent = (
                        (totalRent + building.get("rent", Decimal(0)))
                        if (shouldUpdate == False)
                        else totalRent
                    )
                elif building.get("status", "None") == "Vacant":
                    numVacant += 1
                elif building.get("status", "None") == "Renovation":
                    numRenovation += 1

                buildingExpenses = getTotalExpenses(
                    "building", building["id"], currentMonth, currentYear
                )
                totalFees += buildingExpenses["totalFees"]
                totalOther += buildingExpenses["totalOther"]
                totalOtherExpenses += buildingExpenses["totalOtherExpenses"]
                totalRepairs += buildingExpenses["totalRepairs"]
                totalLostRent += buildingExpenses["totalLostRent"]
                totalRenovation += buildingExpenses["totalRenovation"]
            else:
                unitList = get_unit_list("", buildingID=building["id"])
                for j in range(0, len(unitList)):
                    unit = unitList[j]
                    if unit.get("status", "") == "Occupied":
                        numOccupied += 1
                        totalRent = (
                            (totalRent + unit.get("rent", Decimal(0)))
                            if shouldUpdate == False
                            else totalRent
                        )
                    elif unit.get("status", "None") == "Vacant":
                        numVacant += 1
                    elif unit.get("status", "None") == "Vacant":
                        numRenovation += 1
                    unitExpenses = getTotalExpenses(
                        "unit", unit["id"], currentMonth, currentYear
                    )
                    totalFees += unitExpenses["totalFees"]
                    totalOther += unitExpenses["totalOther"]
                    totalOtherExpenses += unitExpenses["totalOtherExpenses"]
                    totalRepairs += unitExpenses["totalRepairs"]
                    totalLostRent += unitExpenses["totalLostRent"]
                    totalRenovation += unitExpenses["totalRenovation"]
    totalRevenue = totalFees + totalRent + totalOther
    totalExpense = totalRepairs + totalLostRent + totalRenovation + totalOtherExpenses
    totalNet = totalRevenue - totalExpense
    date = datetime.now()
    reportPayload = {
        "id": f"{currentYear}-{currentMonth}-{entityType}-{entityID}",
        "yearlyReportId": f"{currentYear}-{entityType}-{entityID}",
        "status": "Closed" if close == "Closed" else "InProgress",
        "entityType": entityType,
        "entityID": entityID,
        "rentRevenue": Decimal(totalRent),
        "feesRevenue": Decimal(totalFees),
        "otherRevenue": Decimal(totalOther),
        "totalRevenue": Decimal(totalRevenue),
        "repairsExpenses": Decimal(totalLostRent),
        "lostRentExpenses": Decimal(totalRepairs),
        "renovationExpenses": Decimal(totalRenovation),
        "otherExpenses": Decimal(totalOtherExpenses),
        "totalExpenses": Decimal(totalExpense),
        "net": Decimal(totalNet),
        "numOccupied": numOccupied,
        "numVacant": numVacant,
        "numRenovation": numRenovation,
        "month": currentMonth,
        "year": currentYear,
        "updatedAt": datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z"),
        "createdAt": (
            datetime.strftime(date, "%Y-%m-%dT%H:%M:%S.000Z")
            if not shouldUpdate
            else monthlyReport["createdAt"]
        ),
    }
    if shouldUpdate:
        deleteMonthlyReport = delete_monthly_report(monthlyReport["id"])
        updatedMonthlyReport = add_monthly_report(reportPayload)
    else:
        newMonthlyReport = add_monthly_report(reportPayload)
    return reportPayload


def getTotalExpenses(entityType, entityID, month, year):
    totalFees = Decimal(0)
    totalOther = Decimal(0)
    totalLostRent = Decimal(0)
    totalRenovation = Decimal(0)
    totalRepairs = Decimal(0)
    totalOtherExpenses = Decimal(0)
    requestList = get_service_request_list(entityType=entityType, entityID=entityID)
    for r in range(0, len(requestList)):
        request = requestList[r]
        requestCreatedDate = datetime.fromtimestamp(
            float(request["dateCreated"]) / 1000.0
        )
        if (
            (int(requestCreatedDate.month) == int(month))
            and (int(requestCreatedDate.year) == int(year))
            and ("finalCost" in request)
        ):
            if request["type"] == "Repairs":
                totalRepairs += Decimal(request["finalCost"])
            elif request["type"] == "Lost_Rent":
                totalLostRent += Decimal(request["finalCost"])
            elif request["type"] == "Renovation":
                totalRenovation += Decimal(request["finalCost"])
            elif request["type"] == "Fees_Charges":
                totalFees += Decimal(request["finalCost"])
            elif request["type"] == "Other_revenue":
                totalOther += Decimal(request["finalCost"])
            elif request["type"] == "Other_expenses":
                totalOtherExpenses += Decimal(request["finalCost"])
    totalExpenses = totalLostRent + totalRepairs + totalRenovation + totalOtherExpenses
    return {
        "totalFees": totalFees,
        "totalOther": totalOther,
        "totalOtherExpenses": totalOtherExpenses,
        "totalLostRent": totalLostRent,
        "totalRepairs": totalRepairs,
        "totalRenovation": totalRenovation,
        "totalExpenses": totalExpenses,
    }


# Route to generate and return a new unique organization ID
@app.route("/api/v1/generate_organization_id", methods=["GET"])
def generate_organization_id():
    new_organization_id = str(uuid.uuid4())  # Generate a new UUID

    # Extract name from query parameters
    name = request.args.get("name", default="Anonymous")
    print(name)

    # Create a dateCreated variable
    date_created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Create data dictionary to be pushed to Firestore
    data = {
        "organizationId": new_organization_id,
        "name": name,
        "dateCreated": date_created,
    }

    print(data)

    # Push data to Firestore
    push_to_DB("Organizations", new_organization_id, data)

    return jsonify(
        {
            "organizationId": new_organization_id,
            "name": name,
            "dateCreated": date_created,
        }
    )


# Function to push data to Firestore
def push_to_DB(collection_id, document_id, data):
    try:
        print("pushing to db")
        # Replace these values with your Firestore project details
        global project_id
        api_key = "YOUR_API_KEY"  # Replace with your Firestore API key

        # URL for the Firestore REST API
        url_base = f"https://firestore.googleapis.com/v1/projects/{project_id}/databases/(default)/documents/{collection_id}"

        # Ensure data is a dictionary
        if not isinstance(data, dict):
            raise ValueError("Data must be a dictionary")

        # Prepare the data to be posted to Firestore dynamically
        firestore_data = {"fields": {}}

        for key, value in data.items():
            field_type = determine_field_type(value)
            firestore_data["fields"][key] = {
                field_type: convert_to_firestore_value(value)
            }

        # Convert the data to JSON
        firestore_data_json = json.dumps(firestore_data)

        # Make a PATCH request to Firestore to post the data
        document_url = f"{url_base}/{document_id}?key={api_key}"
        response = requests.patch(
            document_url,
            data=firestore_data_json,
            headers={"Content-Type": "application/json"},
        )

        # Check the response
        if response.status_code == 200:
            print(f"Data posted to Firestore successfully.")
        else:
            print(
                f"Failed to post data to Firestore. Status code: {response.status_code}"
            )
            print(response.text)
    except Exception as e:
        print(f"Error: {str(e)}")


def determine_field_type(value):
    if isinstance(value, int):
        return "integerValue"
    elif isinstance(value, Decimal):
        return "doubleValue"
    elif isinstance(value, str):
        return "stringValue"
    elif isinstance(value, list):
        return "arrayValue"
    elif isinstance(value, dict):
        return "mapValue"
    else:
        raise ValueError(f"Unsupported data type: {type(value)}")


def convert_to_firestore_value(value):
    if isinstance(value, list):
        return {
            "arrayValue": {
                "values": [convert_to_firestore_value(item) for item in value]
            }
        }
    elif isinstance(value, dict):
        return {
            "mapValue": {
                "fields": {
                    key: {determine_field_type(v): convert_to_firestore_value(v)}
                    for key, v in value.items()
                }
            }
        }
    else:
        return value


if __name__ == "__main__":
    app.run(debug=True)
